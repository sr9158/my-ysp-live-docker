# 📺 央视频全频道直播 v10.0 使用说明

## 📢 首发地址

社区：[Gary's Club](https://t.me/garysclub)  
频道：[Gary's Club Channel](https://t.me/garysclubchannel)  
⚠️ 其他任何分发渠道均非作者本人！

---

## ✨ 核心亮点

1. 保留设备协议与低码率播放路径；可选伴生引擎需运行环境支持
2. 订阅收录 64 个频道（央视 30 个、卫视分组 34 个），包含超高清频道入口
3. 保留时移回看入口，实际可回看范围与播放结果以上游和播放器支持为准
4. 按频道合并并发请求，按分片进展判断直播缓存是否可用
5. 播放器通过 8767 端口访问直播、回看和分片
6. Docker Compose 一起构建 Python 网关及 Rust Web 服务，数据存放在挂载目录中

---

## 10.0 播放方式

APTV 加载 Python 单文件，支持 API v2 的 JS 播放器加载独立脚本。两者都自带 64 路频道表。局域网播放器也可以直接订阅电脑或 Docker 提供的 `http://服务器IP:8767/all.m3u`。回看请求使用指定时间窗，上游无法返回时显示错误。

Python 服务沿用设备和上游协议编解码，自行管理每个频道的直播清单。首播或切换来源时先读取一个媒体分片。普通连续清单最多保留 36 条分片记录、发布最近最多 12 片，首播直接交付已有清单。分片按播放器请求转发，完整成功的响应可复用，默认共享 96 MB 内存。带密钥、初始化段或不连续标记的清单保留上游结构。

自动直播先用 BK 启播。对支持高码率的 26 个频道，持续观看约 10 秒后，Python 服务会在后续清单请求中后台准备设备线路，JS 脚本则利用宿主的播放活动和 HLS 刷新回调准备、切换。取得高码率档位并读到媒体分片后，播放器沿用当前地址升档。准备失败时继续使用可用的原线路。约 10 秒是开始尝试的时间，实际切换时间和分辨率取决于上游、网络和播放器。未启用设备协议时仅使用普通线路。对于需要在打开时就确定视频编码的播放器，Python 服务可直接使用高码率频道地址，例如 `http://127.0.0.1:8767/cctv4k.m3u8?source=device`。这个入口会等待设备线路，无法取得高码率时返回错误。播放中的分片请求失败后，Python 服务会在该频道下一次刷新清单时重新选源。JCE 提供受支持频道的回看和直播备用窗口。Python 只有配置 Web 服务或启动包内编译的程序后才使用 Rust Web 来源。上游限流或拒绝、网络质量及客户端支持都会影响实际可播性。JS 播放器由宿主 HLS 会话管理分片；打开会话或刷新失败可在后续解析时重新选择来源。

---

## 💻 电脑版使用方法（PC / Mac / Linux）

1. 下载地址：<https://raw.githubusercontent.com/ideal4live/iptv/main/ysp-live/ysp-live-v10.0.zip>
2. 安装 Python 3.10 或更新版本。Python 可以独立运行。要在电脑启用额外的 Web 来源，可安装 Rust 1.94，进入包内 `ysp-web/rust-src` 执行 `cargo build --locked --release`，然后重新启动 Python。也可用 `--web-url http://地址:8787` 连接已部署的同版 Web 服务。
3. 解压进入目录直接运行：
   ```bash
   python3 ysp-live-v10.0.py
   ```
   （可选）后台常驻运行：
   ```bash
   nohup python3 ysp-live-v10.0.py > ysp.log 2>&1 &
   ```
4. 播放器添加订阅地址：`http://localhost:8767/all.m3u`

---

## 🐳 Docker 版使用与升级方法

1. 下载地址：<https://raw.githubusercontent.com/ideal4live/iptv/main/ysp-live/ysp-live-docker-v10.0.zip>
2. 升级前停用旧容器并保留原有持久化数据，解压进入 10.0 目录。核对 compose 中的数据挂载仍指向原目录后构建启动：
   ```bash
   docker compose up -d --build
   ```
3. 播放器添加订阅地址：
   - 电脑本机播放：`http://localhost:8767/all.m3u`
   - 局域网播放：`http://你的局域网IP:8767/all.m3u`

---

## 📱 APTV / iOS 使用方法

1. 升级时先停用旧服务，避免两份服务争用 8767 端口。点击 “配置” ➔ “服务” ➔ “添加服务”
2. 服务名称：`央视频直播`
3. 服务类型：`Python`
4. 代码来源选择 “远程链接”，地址填写：`https://raw.githubusercontent.com/ideal4live/iptv/main/ysp-live/ysp-live-v10.0.py`
5. 点击 “加载代码” ➔ 划到底部点击 “添加服务” ➔ 打开服务开关
6. 前往 APTV “添加订阅”，地址填写：`http://127.0.0.1:8767/all.m3u`

若原服务支持更换代码链接，可将地址改为上方 10.0 链接后重新加载。APTV 单文件可以独立运行。

---

## nanoTV TF / JavaScript 订阅

1. 打开“设置 → 通用 → 实验”，启用“JS订阅”。
2. 打开“订阅 → 添加 → JavaScript”。
3. 填写脚本地址：`https://raw.githubusercontent.com/ideal4live/iptv/main/ysp-live/ysp-service_10.0.js`
4. 点击「读取脚本」→「批准并安装」，然后启用服务。

nanoTV 使用独立发行的 JavaScript 脚本，当前版本为 `10.0`。

---

## mytv-android 当前预览版 / 脚本服务

以下入口按当前预览版说明整理，实际名称以所安装版本为准。

1. **准备运行环境**：Python 方式要求 Android 7 及以上，并安装“Python运行环境”组件。可在设置或 Web 面板中搜索组件，或进入“设置 → 投屏与扩展 → 组件下载”安装。JavaScript 方式不需要 Python 组件。
2. 搜索“脚本服务”并选择“添加服务”，或进入“设置 → 投屏与扩展 → 脚本服务 → 添加服务”。
3. 名称填写“央视频直播”，代码来源选择“远程链接”；按所选脚本类型填入地址：
   - Python：`https://raw.githubusercontent.com/ideal4live/iptv/main/ysp-live/ysp-live-v10.0.py`
   - JavaScript：`https://raw.githubusercontent.com/ideal4live/iptv/main/ysp-live/ysp-service_10.0.js`
4. 勾选“启用” → “确定”。
5. 长按该服务 → “添加为订阅源”。

Python 和 JS 入口都使用 10.0。JS 宿主需要支持声明中的 API v2、Host SDK 2.2 和 HLS 媒体会话。

---

## 🚀 翻墙/代理工具分流配置

1. **小火箭（Shadowrocket）分流规则**：  
   打开小火箭，点击底部 「配置」 -> 「模块」。  
   点击右上角 「+」，粘贴模块链接： `https://garysclub.sharewithyou.dpdns.org/ysp-live/ysp.module`
2. **通用规则集（Surge / Loon / Clash 等）**：  
   规则集地址：`https://garysclub.sharewithyou.dpdns.org/ysp-live/ysp.list`

---

## 排障与使用边界

- 原有运行数据不要清空。遇到问题先保存频道名、时间和错误类型；分享日志前删除设备标识、签名、令牌和完整播放地址。
- 健康检查：`http://localhost:8767/health`；诊断：`http://localhost:8767/diag`。其他设备访问时，将 localhost 换成服务所在设备的局域网 IP。
- 观看流量随实际码率变化，4K 通常显著高于普通清晰度。请确认网络与数据套餐。
- 本地服务请仅在可信网络使用。是否能播放仍受上游授权、网络、频道状态及运行环境影响。

---

## 🙏 特别感谢

1. 感谢 **IPTV 直播源总部** 分享的算法源码
2. 感谢 **Gary's Club** 群里小伙伴 **ll** 提供大量频道的 live_id
3. 感谢 **APTV 群主** 提供的技术帮助

