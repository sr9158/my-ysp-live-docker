from __future__ import annotations
import argparse
import base64
import binascii
import collections
import contextlib
import dataclasses
import gzip
import hashlib
import hmac as _hmac
import http.client
import http.cookiejar
import json
import math
import os
import secrets
import socket
import ssl
import sys
import threading
import time
import urllib.error
import urllib.parse
import urllib.request
import uuid

import random
import re
import datetime as dt
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from urllib.parse import urlsplit, urljoin, parse_qs
from pathlib import Path

VERSION = "10.0"

__version__ = VERSION

AK = "9f5c54c4ed0e50109b800f7e28fec205"

RSA_PUBLIC_KEY_B64 = (
    "MIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEAkKeLy4ywWLSnBkwRyqYgF3HMIj05V5uuh5HjyEsZOWnu1NHu3jPQv3sr32wwQNYv5qa"
    "psNXmNgLUDHtgHZxqPQAYXltjSRc0qhcD286t62wOIHId8zXS3s1Jy4rgU4qjQWzI9rp/1sE0pMsmwTaJa4zuJ5iz8VwF8Av5oJ1k+HxY+/HLnj"
    "NlW1hmWLpuDYmkZYuAoTHa1VGeHQh9FEKI8ZcL3GTQphShUoC+Kg3P1hGUVTtCYapmzPS5lkAdwebuzwvTCfGiTErYZCnPBUSeV7BVlgjtLYIi2"
    "9KvF0a8FHsJMfe/UdHcyW/RihsIYOtDQcRRpFGXyPXbVrzFJse24QIDAQAB"
)

CLOUD_GET_URL = "https://ytpcloudws.cctv.cn/cloudps/wssapi/device/v2/get"

CLOUD_REGISTER_URL = "https://ytpcloudws.cctv.cn/cloudps/wssapi/device/v2/register"

APP_START_URL = "https://ytpaddr.cctv.cn/gsnw/api/app/start/v1/01"

DRM_CONFIG_URL = "https://ytpaddr.cctv.cn/gsnw/drm/config/obtain/v1"

VERSION_CONFIG_URL = "https://ytpaddr.cctv.cn/gsnw/version/config/obtain/v1"

DICTIONARY_URL = "https://ytpaddr.cctv.cn/gsnw/player/dictionary/obtain/v1"

INDEX_URL = "https://ytpaddr.cctv.cn/gsnw/api/index/v1/01"

REPORT_SINGLE_URL = "https://ytpdata.cctv.cn/das/app/data/message/single"

COLLECT_REPORT_URL = "https://collect.cctv.cn/cctvmobileinf/rest/cctv/receive/new/app"

LIVE_V1_01_URL = "https://ytpaddr.cctv.cn/gsnw/api/live/v1/01"

LIVE_V1_02_URL = "https://ytpaddr.cctv.cn/gsnw/api/live/v1/02"

VDN_GETSTREAM_URL = (
    "https://ytpvdn.cctv.cn/cctvmobileinf/rest/cctv/videoliveUrl/getstream"
)

DEFAULT_LIVE_USER_ID = "BAEBFF2B-C516-4F34-ABC0-A824A6461CBD"

DEFAULT_DEVICE_NAME = "央视频电视投屏助手"

VDN_APP_NAME = "央视频电视投屏助手"

REPORT_APP_KEY = "1178c84d-4818-44ff-b415-02106e87e144"

COLLECT_SDK_VERSION = "1.0.0"

DEFAULT_PAGE_NAME = "com.cctv.tv.mvp.ui.activity.MainActivity"

DEFAULT_ACCEPT_LANGUAGE = "zh-CN,zh;q=0.8"

RESULT_OK = 0

RESULT_NEEDS_REGISTER = 601

RESULT_GET_MISSING_OR_INVALID = 2

RESULT_REGISTERED_ELSEWHERE = 694

RESULT_REGISTER_RETRY_LATER = 695

_SBOX = (
    0x63,
    0x7C,
    0x77,
    0x7B,
    0xF2,
    0x6B,
    0x6F,
    0xC5,
    0x30,
    0x01,
    0x67,
    0x2B,
    0xFE,
    0xD7,
    0xAB,
    0x76,
    0xCA,
    0x82,
    0xC9,
    0x7D,
    0xFA,
    0x59,
    0x47,
    0xF0,
    0xAD,
    0xD4,
    0xA2,
    0xAF,
    0x9C,
    0xA4,
    0x72,
    0xC0,
    0xB7,
    0xFD,
    0x93,
    0x26,
    0x36,
    0x3F,
    0xF7,
    0xCC,
    0x34,
    0xA5,
    0xE5,
    0xF1,
    0x71,
    0xD8,
    0x31,
    0x15,
    0x04,
    0xC7,
    0x23,
    0xC3,
    0x18,
    0x96,
    0x05,
    0x9A,
    0x07,
    0x12,
    0x80,
    0xE2,
    0xEB,
    0x27,
    0xB2,
    0x75,
    0x09,
    0x83,
    0x2C,
    0x1A,
    0x1B,
    0x6E,
    0x5A,
    0xA0,
    0x52,
    0x3B,
    0xD6,
    0xB3,
    0x29,
    0xE3,
    0x2F,
    0x84,
    0x53,
    0xD1,
    0x00,
    0xED,
    0x20,
    0xFC,
    0xB1,
    0x5B,
    0x6A,
    0xCB,
    0xBE,
    0x39,
    0x4A,
    0x4C,
    0x58,
    0xCF,
    0xD0,
    0xEF,
    0xAA,
    0xFB,
    0x43,
    0x4D,
    0x33,
    0x85,
    0x45,
    0xF9,
    0x02,
    0x7F,
    0x50,
    0x3C,
    0x9F,
    0xA8,
    0x51,
    0xA3,
    0x40,
    0x8F,
    0x92,
    0x9D,
    0x38,
    0xF5,
    0xBC,
    0xB6,
    0xDA,
    0x21,
    0x10,
    0xFF,
    0xF3,
    0xD2,
    0xCD,
    0x0C,
    0x13,
    0xEC,
    0x5F,
    0x97,
    0x44,
    0x17,
    0xC4,
    0xA7,
    0x7E,
    0x3D,
    0x64,
    0x5D,
    0x19,
    0x73,
    0x60,
    0x81,
    0x4F,
    0xDC,
    0x22,
    0x2A,
    0x90,
    0x88,
    0x46,
    0xEE,
    0xB8,
    0x14,
    0xDE,
    0x5E,
    0x0B,
    0xDB,
    0xE0,
    0x32,
    0x3A,
    0x0A,
    0x49,
    0x06,
    0x24,
    0x5C,
    0xC2,
    0xD3,
    0xAC,
    0x62,
    0x91,
    0x95,
    0xE4,
    0x79,
    0xE7,
    0xC8,
    0x37,
    0x6D,
    0x8D,
    0xD5,
    0x4E,
    0xA9,
    0x6C,
    0x56,
    0xF4,
    0xEA,
    0x65,
    0x7A,
    0xAE,
    0x08,
    0xBA,
    0x78,
    0x25,
    0x2E,
    0x1C,
    0xA6,
    0xB4,
    0xC6,
    0xE8,
    0xDD,
    0x74,
    0x1F,
    0x4B,
    0xBD,
    0x8B,
    0x8A,
    0x70,
    0x3E,
    0xB5,
    0x66,
    0x48,
    0x03,
    0xF6,
    0x0E,
    0x61,
    0x35,
    0x57,
    0xB9,
    0x86,
    0xC1,
    0x1D,
    0x9E,
    0xE1,
    0xF8,
    0x98,
    0x11,
    0x69,
    0xD9,
    0x8E,
    0x94,
    0x9B,
    0x1E,
    0x87,
    0xE9,
    0xCE,
    0x55,
    0x28,
    0xDF,
    0x8C,
    0xA1,
    0x89,
    0x0D,
    0xBF,
    0xE6,
    0x42,
    0x68,
    0x41,
    0x99,
    0x2D,
    0x0F,
    0xB0,
    0x54,
    0xBB,
    0x16,
)

_RCON = (0x01, 0x02, 0x04, 0x08, 0x10, 0x20, 0x40, 0x80, 0x1B, 0x36)


def _xtime(a: int) -> int:
    return ((a << 1) ^ 0x11B) & 0xFF if a & 0x80 else (a << 1) & 0xFF


def _aes256_key_schedule(key: bytes):
    """Return 15 round keys (each 16 bytes) for a 32-byte key."""
    assert len(key) == 32
    w = [int.from_bytes(key[i : i + 4], "big") for i in range(0, 32, 4)]
    for i in range(8, 60):
        temp = w[i - 1]
        if i % 8 == 0:
            temp = (
                (_SBOX[(temp >> 16) & 0xFF] << 24)
                | (_SBOX[(temp >> 8) & 0xFF] << 16)
                | (_SBOX[temp & 0xFF] << 8)
                | _SBOX[(temp >> 24) & 0xFF]
            )
            temp ^= _RCON[i // 8 - 1] << 24
        elif i % 8 == 4:
            temp = (
                (_SBOX[(temp >> 24) & 0xFF] << 24)
                | (_SBOX[(temp >> 16) & 0xFF] << 16)
                | (_SBOX[(temp >> 8) & 0xFF] << 8)
                | _SBOX[temp & 0xFF]
            )
        w.append(w[i - 8] ^ temp)
    return [
        b"".join(word.to_bytes(4, "big") for word in w[i : i + 4])
        for i in range(0, 60, 4)
    ]


def _add_round_key(state, rk: bytes):
    for i in range(16):
        state[i] ^= rk[i]


def _sub_bytes(state):
    for i in range(16):
        state[i] = _SBOX[state[i]]


def _shift_rows(s):
    s[1], s[5], s[9], s[13] = s[5], s[9], s[13], s[1]
    s[2], s[6], s[10], s[14] = s[10], s[14], s[2], s[6]
    s[3], s[7], s[11], s[15] = s[15], s[3], s[7], s[11]


def _mix_columns(s):
    # Standard column-major layout: column c = bytes s[4c .. 4c+3].
    for c in range(4):
        a0, a1, a2, a3 = s[4 * c], s[4 * c + 1], s[4 * c + 2], s[4 * c + 3]
        s[4 * c] = _xtime(a0) ^ (_xtime(a1) ^ a1) ^ a2 ^ a3
        s[4 * c + 1] = a0 ^ _xtime(a1) ^ (_xtime(a2) ^ a2) ^ a3
        s[4 * c + 2] = a0 ^ a1 ^ _xtime(a2) ^ (_xtime(a3) ^ a3)
        s[4 * c + 3] = (_xtime(a0) ^ a0) ^ a1 ^ a2 ^ _xtime(a3)


def aes256_encrypt_block(key: bytes, block: bytes) -> bytes:
    rk = _aes256_key_schedule(key)
    s = bytearray(block)
    _add_round_key(s, rk[0])
    for rnd in range(1, 14):
        _sub_bytes(s)
        _shift_rows(s)
        _mix_columns(s)
        _add_round_key(s, rk[rnd])
    _sub_bytes(s)
    _shift_rows(s)
    _add_round_key(s, rk[14])
    return bytes(s)


def _gf_mult(x: int, y: int) -> int:
    r = 0xE1000000000000000000000000000000
    z = 0
    v = y
    for _ in range(128):
        if x & 0x80000000000000000000000000000000:
            z ^= v
        if v & 1:
            v = (v >> 1) ^ r
        else:
            v >>= 1
        x = (x << 1) & 0xFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF
    return z


def _ghash(h: int, aad: bytes, ct: bytes) -> int:
    x = 0

    def _blocks(data: bytes):
        for i in range(0, len(data), 16):
            blk = data[i : i + 16]
            if len(blk) < 16:
                blk = blk + b"\x00" * (16 - len(blk))
            yield int.from_bytes(blk, "big")

    for b in _blocks(aad):
        x = _gf_mult(x ^ b, h)
    for b in _blocks(ct):
        x = _gf_mult(x ^ b, h)
    lens = ((len(aad) * 8) << 64) | (len(ct) * 8)
    x = _gf_mult(x ^ lens, h)
    return x


def _inc32(block: bytes) -> bytes:
    ctr = int.from_bytes(block[12:], "big")
    return block[:12] + ((ctr + 1) & 0xFFFFFFFF).to_bytes(4, "big")


def _gctr(key: bytes, icb: bytes, data: bytes) -> bytes:
    """GCTR_K(ICB, X): first block uses E(K, ICB) directly (SP 800-38D)."""
    out = bytearray()
    cb = icb
    for i in range(0, len(data), 16):
        ks = aes256_encrypt_block(key, cb)
        chunk = data[i : i + 16]
        out += bytes(a ^ b for a, b in zip(chunk, ks))
        cb = _inc32(cb)
    return bytes(out)


def aes_gcm_encrypt(
    key: bytes, nonce: bytes, plaintext: bytes, aad: bytes = b""
) -> bytes:
    """Return ciphertext || 16-byte tag (matches aes-gcm crate output layout)."""
    assert len(key) == 32 and len(nonce) == 12
    h = int.from_bytes(aes256_encrypt_block(key, b"\x00" * 16), "big")
    j0 = nonce + b"\x00\x00\x00\x01"
    ct = _gctr(key, _inc32(j0), plaintext)
    s = _ghash(h, aad, ct).to_bytes(16, "big")
    # T = MSB_128(GCTR_K(J0, S)): the tag block uses E(K, J0) directly.
    tag = bytes(a ^ b for a, b in zip(aes256_encrypt_block(key, j0), s))
    return ct + tag


def aes_gcm_decrypt(
    key: bytes, nonce: bytes, ct_and_tag: bytes, aad: bytes = b""
) -> bytes:
    if len(ct_and_tag) < 16:
        raise ValueError("AES-GCM payload too short")
    ct, tag = ct_and_tag[:-16], ct_and_tag[-16:]
    h = int.from_bytes(aes256_encrypt_block(key, b"\x00" * 16), "big")
    j0 = nonce + b"\x00\x00\x00\x01"
    s = _ghash(h, aad, ct).to_bytes(16, "big")
    expect = bytes(a ^ b for a, b in zip(aes256_encrypt_block(key, j0), s))
    if not _hmac.compare_digest(tag, expect):
        raise ValueError("AES-GCM decrypt failed")
    return _gctr(key, _inc32(j0), ct)


def _mgf1_sha256(seed: bytes, length: int) -> bytes:
    out = bytearray()
    counter = 0
    while len(out) < length:
        out += hashlib.sha256(seed + counter.to_bytes(4, "big")).digest()
        counter += 1
    return bytes(out[:length])


def _oaep_encode_sha256(message: bytes, k: int, seed: bytes) -> bytes:
    hlen = 32
    if len(message) > k - 2 * hlen - 2:
        raise ValueError("OAEP message too long")
    lhash = hashlib.sha256(b"").digest()
    ps = b"\x00" * (k - len(message) - 2 * hlen - 2)
    db = lhash + ps + b"\x01" + message
    db_mask = _mgf1_sha256(seed, k - hlen - 1)
    masked_db = bytes(a ^ b for a, b in zip(db, db_mask))
    seed_mask = _mgf1_sha256(masked_db, hlen)
    masked_seed = bytes(a ^ b for a, b in zip(seed, seed_mask))
    return b"\x00" + masked_seed + masked_db


def _der_read_tlv(der: bytes, pos: int):
    assert der[pos] == 0x30, "expected SEQUENCE"
    pos += 1
    ln, pos = _der_read_len(der, pos)
    end = pos + ln
    items = []
    while pos < end:
        tag = der[pos]
        pos += 1
        ln2, pos = _der_read_len(der, pos)
        items.append((tag, der[pos : pos + ln2]))
        pos += ln2
    return items


def _der_read_len(der: bytes, pos: int):
    first = der[pos]
    pos += 1
    if first & 0x80 == 0:
        return first, pos
    n = first & 0x7F
    return int.from_bytes(der[pos : pos + n], "big"), pos + n


def _der_read_int(raw: bytes) -> int:
    return int.from_bytes(raw, "big")


def parse_spki_rsa_pubkey(der: bytes):
    """Parse DER SubjectPublicKeyInfo -> (n, e)."""
    outer = _der_read_tlv(der, 0)
    bitstring = outer[1][1]
    assert bitstring[0] == 0x00
    inner = _der_read_tlv(bitstring[1:], 0)
    n = _der_read_int(inner[0][1])
    e = _der_read_int(inner[1][1])
    return n, e


def rsa_oaep_sha256_encrypt(der: bytes, message: bytes, seed: bytes) -> bytes:
    n, e = parse_spki_rsa_pubkey(der)
    k = (n.bit_length() + 7) // 8
    em = _oaep_encode_sha256(message, k, seed)
    m = int.from_bytes(em, "big")
    c = pow(m, e, n)
    return c.to_bytes(k, "big")


class YsptpError(Exception):
    """Port of anyhow::Error for this program (message carries full context)."""


def now_f64() -> float:
    return time.time()


def current_time_ms() -> int:
    return int(now_f64() * 1000.0)


def sha1_upper(value: str) -> str:
    return hashlib.sha1(value.encode("utf-8")).hexdigest().upper()


def sha256_hex(value: str) -> str:
    return hashlib.sha256(value.encode("utf-8")).hexdigest()


def md5_hex(value: str) -> str:
    return hashlib.md5(value.encode("utf-8")).hexdigest()


def log_program_fetching() -> None:
    print("程序获取直播源中", file=sys.stderr)


def log_channel_ready(channel: str) -> None:
    print(f"程序已成功获取{channel}的直播源", file=sys.stderr)


def java_string_hashcode(value: str) -> int:
    """Java String.hashCode() with 32-bit wrapping (Rust wrapping_mul/add)."""
    h = 0
    for ch in value:
        h = ((h * 31) + ord(ch)) & 0xFFFFFFFF
    return h - 0x100000000 if h & 0x80000000 else h


def java_uuid_from_hashes(msb_hash: int, lsb_hash: int) -> str:
    # Rust: (msb_hash as i64 as u64 as u128) << 64 | (lsb_hash as i64 as u64 as u128)
    msb = msb_hash & 0xFFFFFFFFFFFFFFFF
    lsb = lsb_hash & 0xFFFFFFFFFFFFFFFF
    return f"{(msb << 64) | lsb:032x}"


def native_day0_ms(now_s: int) -> int:
    return 86_400_000 * ((now_s + 28_800) // 86_400) - 28_800_000


def compute_fingerprint(x_uid: str, now_ms: int):
    day0_ms = native_day0_ms(now_ms // 1000)
    first = sha256_hex(f"{AK}{x_uid}{now_ms}{day0_ms}")
    return sha256_hex(first), now_ms, day0_ms


def random_hex_string(length: int) -> str:
    return "".join(secrets.choice("0123456789abcdef") for _ in range(length))


def random_mac_address() -> str:
    raw = bytearray(secrets.token_bytes(6))
    raw[0] = (raw[0] | 0x02) & 0xFE
    return ":".join(f"{b:02x}" for b in raw)


def sanitize_profile_id(value: str) -> str:
    out = []
    last_underscore = False
    for ch in value:
        if ch.isascii() and ch.isalnum():
            out.append(ch.lower())
            last_underscore = False
        elif not last_underscore:
            out.append("_")
            last_underscore = True
    return "".join(out).strip("_")


def resolution_from_screen_param(screen_param: str) -> str:
    parts = screen_param.split("-")
    if len(parts) >= 2 and parts[0] and parts[1]:
        return f"{parts[0]}*{parts[1]}"
    return "3840*2160"


def channels():
    return list(DEVICE_IDS.items())


def channel_by_name(name: str):
    for c, live_id in channels():
        if c == name:
            return live_id
    return None


def has_http_400(lower: str) -> bool:
    return "http 400" in lower or "status=400" in lower


def is_session_core_http_400(lower: str) -> bool:
    return has_http_400(lower) and any(
        needle in lower
        for needle in ("app/start", "live/v1/01", "live/v1/02", "vdn", "heartbeat")
    )


def is_session_invalidating_error(message: str) -> bool:
    lower = message.lower()
    return (
        "app/start" in lower
        or "decrypt" in lower
        or "session_key" in lower
        or "missing encrypted session key" in lower
        or is_session_core_http_400(lower)
        or "live/v1/01 http 400" in lower
        or "live/v1/01 http 401" in lower
        or "live/v1/01 http 403" in lower
        or "live/v1/02 http 400" in lower
        or "live/v1/02 http 401" in lower
        or "live/v1/02 http 403" in lower
    )


@dataclasses.dataclass
class DeviceProfile:
    android_id: str = ""
    mac: str = ""
    hardware: str = ""
    board: str = ""
    brand: str = ""
    device: str = ""
    manufacturer: str = ""
    model: str = ""
    product: str = ""
    tags: str = ""
    build_type: str = ""
    user: str = ""
    resolution: str = ""
    display: str = ""
    version_id: str = ""
    host: str = ""
    fingerprint: str = ""
    report_model: str = ""

    @classmethod
    def from_dict(cls, d: dict) -> "DeviceProfile":
        return cls(**{f.name: str(d.get(f.name, "")) for f in dataclasses.fields(cls)})


@dataclasses.dataclass
class DeviceState:
    schema_version: int = 1
    profile_source: str = ""
    profile: DeviceProfile = dataclasses.field(default_factory=DeviceProfile)
    screen_param: str = ""
    cast_model: str = ""
    x_uid: str = ""
    cloud_guid: str = ""
    registered_at: float = 0.0
    updated_at: float = 0.0


@dataclasses.dataclass
class Identity:
    x_uid: str = ""
    x_fingerprint: str = ""
    fingerprint_timestamp_ms: int = 0
    headers: dict = dataclasses.field(default_factory=dict)


@dataclasses.dataclass
class ChannelEntry:
    channel: str = ""
    live_id: str = ""
    final_url: str = ""
    playback_headers: dict = dataclasses.field(default_factory=dict)
    android_id: str = ""
    x_uid: str = ""
    rate: str = ""
    rate_name: str = ""
    raw_live_host: str = ""
    final_host: str = ""
    refreshed_at: float = 0.0
    expires_at: float = 0.0
    generation: int = 0
    last_refresh_error: str = ""
    last_refresh_failed_at: float = 0.0
    session_generation: int = 0

    def fresh(self, now: float) -> bool:
        return bool(self.final_url) and now < self.expires_at

    def stale_usable(self, now: float, ttl: float) -> bool:
        return bool(self.final_url) and ttl > 0.0 and now < self.expires_at + ttl

    @classmethod
    def from_dict(cls, d: dict) -> "ChannelEntry":
        kwargs = {}
        for f in dataclasses.fields(cls):
            v = d.get(
                f.name, f.default if f.default is not dataclasses.MISSING else None
            )
            if f.name == "playback_headers":
                v = dict(v) if isinstance(v, dict) else {}
            kwargs[f.name] = v
        return cls(**kwargs)


@dataclasses.dataclass
class AppStartResult:
    session_key: str = ""


@dataclasses.dataclass
class Live01Result:
    live_url: str = ""
    rate: str = ""
    rate_name: str = ""


@dataclasses.dataclass
class VdnGetStreamResult:
    final_url: str = ""
    app_sign: str = ""
    app_random_str: str = ""


DEVICE_PROFILE_POOL = [
    {
        "source": "sony_8k_pool.XR-85Z9K",
        "brand": "Sony",
        "manufacturer": "Sony",
        "model": "XR-85Z9K",
        "report_model": "XR85Z9K",
        "hardware": "mt5895",
        "board": "mt5895",
        "version_id": "SONYTV.2022.XR_85Z9K",
        "screen_param": "7680-4320-280",
        "cast_model": "XR-85Z9K",
    },
    {
        "source": "sony_8k_pool.XR-75Z9K",
        "brand": "Sony",
        "manufacturer": "Sony",
        "model": "XR-75Z9K",
        "report_model": "XR75Z9K",
        "hardware": "mt5895",
        "board": "mt5895",
        "version_id": "SONYTV.2022.XR_75Z9K",
        "screen_param": "7680-4320-260",
        "cast_model": "XR-75Z9K",
    },
    {
        "source": "sony_8k_pool.XR-85Z9J",
        "brand": "Sony",
        "manufacturer": "Sony",
        "model": "XR-85Z9J",
        "report_model": "XR85Z9J",
        "hardware": "mt5895",
        "board": "mt5895",
        "version_id": "SONYTV.2021.XR_85Z9J",
        "screen_param": "7680-4320-280",
        "cast_model": "XR-85Z9J",
    },
    {
        "source": "sony_8k_pool.XR-75Z9J",
        "brand": "Sony",
        "manufacturer": "Sony",
        "model": "XR-75Z9J",
        "report_model": "XR75Z9J",
        "hardware": "mt5895",
        "board": "mt5895",
        "version_id": "SONYTV.2021.XR_75Z9J",
        "screen_param": "7680-4320-260",
        "cast_model": "XR-75Z9J",
    },
    {
        "source": "sony_8k_pool.KD-98ZG9",
        "brand": "Sony",
        "manufacturer": "Sony",
        "model": "KD-98ZG9",
        "report_model": "KD98ZG9",
        "hardware": "mt5893",
        "board": "mt5893",
        "version_id": "SONYTV.2019.KD_98ZG9",
        "screen_param": "7680-4320-320",
        "cast_model": "KD-98ZG9",
    },
    {
        "source": "sony_8k_pool.KD-85ZG9",
        "brand": "Sony",
        "manufacturer": "Sony",
        "model": "KD-85ZG9",
        "report_model": "KD85ZG9",
        "hardware": "mt5893",
        "board": "mt5893",
        "version_id": "SONYTV.2019.KD_85ZG9",
        "screen_param": "7680-4320-280",
        "cast_model": "KD-85ZG9",
    },
    {
        "source": "sony_8k_pool.KD-85ZH8",
        "brand": "Sony",
        "manufacturer": "Sony",
        "model": "KD-85ZH8",
        "report_model": "KD85ZH8",
        "hardware": "mt5893",
        "board": "mt5893",
        "version_id": "SONYTV.2020.KD_85ZH8",
        "screen_param": "7680-4320-280",
        "cast_model": "KD-85ZH8",
    },
    {
        "source": "sony_8k_pool.KD-75ZH8",
        "brand": "Sony",
        "manufacturer": "Sony",
        "model": "KD-75ZH8",
        "report_model": "KD75ZH8",
        "hardware": "mt5893",
        "board": "mt5893",
        "version_id": "SONYTV.2020.KD_75ZH8",
        "screen_param": "7680-4320-260",
        "cast_model": "KD-75ZH8",
    },
    {
        "source": "samsung_8k_pool.QA85QN900A",
        "brand": "Samsung",
        "manufacturer": "Samsung",
        "model": "QA85QN900A",
        "report_model": "QA85QN900A",
        "hardware": "s5e9925",
        "board": "neo8k",
        "version_id": "SAMSUNGTV.2021.QN900A",
        "screen_param": "7680-4320-280",
        "cast_model": "QA85QN900A",
    },
    {
        "source": "samsung_8k_pool.QA75QN900A",
        "brand": "Samsung",
        "manufacturer": "Samsung",
        "model": "QA75QN900A",
        "report_model": "QA75QN900A",
        "hardware": "s5e9925",
        "board": "neo8k",
        "version_id": "SAMSUNGTV.2021.QN900A",
        "screen_param": "7680-4320-260",
        "cast_model": "QA75QN900A",
    },
    {
        "source": "samsung_8k_pool.QA85QN900B",
        "brand": "Samsung",
        "manufacturer": "Samsung",
        "model": "QA85QN900B",
        "report_model": "QA85QN900B",
        "hardware": "s5e9925",
        "board": "neo8k",
        "version_id": "SAMSUNGTV.2022.QN900B",
        "screen_param": "7680-4320-280",
        "cast_model": "QA85QN900B",
    },
    {
        "source": "samsung_8k_pool.QA75QN900B",
        "brand": "Samsung",
        "manufacturer": "Samsung",
        "model": "QA75QN900B",
        "report_model": "QA75QN900B",
        "hardware": "s5e9925",
        "board": "neo8k",
        "version_id": "SAMSUNGTV.2022.QN900B",
        "screen_param": "7680-4320-260",
        "cast_model": "QA75QN900B",
    },
    {
        "source": "samsung_8k_pool.QA85QN900C",
        "brand": "Samsung",
        "manufacturer": "Samsung",
        "model": "QA85QN900C",
        "report_model": "QA85QN900C",
        "hardware": "s5e9935",
        "board": "neo8k",
        "version_id": "SAMSUNGTV.2023.QN900C",
        "screen_param": "7680-4320-280",
        "cast_model": "QA85QN900C",
    },
    {
        "source": "samsung_8k_pool.QA75QN900C",
        "brand": "Samsung",
        "manufacturer": "Samsung",
        "model": "QA75QN900C",
        "report_model": "QA75QN900C",
        "hardware": "s5e9935",
        "board": "neo8k",
        "version_id": "SAMSUNGTV.2023.QN900C",
        "screen_param": "7680-4320-260",
        "cast_model": "QA75QN900C",
    },
    {
        "source": "samsung_8k_pool.QA85QN900D",
        "brand": "Samsung",
        "manufacturer": "Samsung",
        "model": "QA85QN900D",
        "report_model": "QA85QN900D",
        "hardware": "s5e9945",
        "board": "neo8k",
        "version_id": "SAMSUNGTV.2024.QN900D",
        "screen_param": "7680-4320-280",
        "cast_model": "QA85QN900D",
    },
    {
        "source": "samsung_8k_pool.QA98QN990C",
        "brand": "Samsung",
        "manufacturer": "Samsung",
        "model": "QA98QN990C",
        "report_model": "QA98QN990C",
        "hardware": "s5e9935",
        "board": "neo8k",
        "version_id": "SAMSUNGTV.2023.QN990C",
        "screen_param": "7680-4320-320",
        "cast_model": "QA98QN990C",
    },
    {
        "source": "samsung_8k_pool.QA85QN800C",
        "brand": "Samsung",
        "manufacturer": "Samsung",
        "model": "QA85QN800C",
        "report_model": "QA85QN800C",
        "hardware": "s5e9935",
        "board": "neo8k",
        "version_id": "SAMSUNGTV.2023.QN800C",
        "screen_param": "7680-4320-280",
        "cast_model": "QA85QN800C",
    },
    {
        "source": "samsung_8k_pool.QA75QN800D",
        "brand": "Samsung",
        "manufacturer": "Samsung",
        "model": "QA75QN800D",
        "report_model": "QA75QN800D",
        "hardware": "s5e9945",
        "board": "neo8k",
        "version_id": "SAMSUNGTV.2024.QN800D",
        "screen_param": "7680-4320-260",
        "cast_model": "QA75QN800D",
    },
    {
        "source": "lg_8k_pool.OLED88Z1PCA",
        "brand": "LG",
        "manufacturer": "LGE",
        "model": "OLED88Z1PCA",
        "report_model": "OLED88Z1PCA",
        "hardware": "alpha9gen4",
        "board": "lg8k",
        "version_id": "LGTV.2021.OLED88Z1",
        "screen_param": "7680-4320-320",
        "cast_model": "OLED88Z1PCA",
    },
    {
        "source": "lg_8k_pool.OLED77Z1PCA",
        "brand": "LG",
        "manufacturer": "LGE",
        "model": "OLED77Z1PCA",
        "report_model": "OLED77Z1PCA",
        "hardware": "alpha9gen4",
        "board": "lg8k",
        "version_id": "LGTV.2021.OLED77Z1",
        "screen_param": "7680-4320-260",
        "cast_model": "OLED77Z1PCA",
    },
    {
        "source": "lg_8k_pool.OLED88Z2PCA",
        "brand": "LG",
        "manufacturer": "LGE",
        "model": "OLED88Z2PCA",
        "report_model": "OLED88Z2PCA",
        "hardware": "alpha9gen5",
        "board": "lg8k",
        "version_id": "LGTV.2022.OLED88Z2",
        "screen_param": "7680-4320-320",
        "cast_model": "OLED88Z2PCA",
    },
    {
        "source": "lg_8k_pool.OLED77Z2PCA",
        "brand": "LG",
        "manufacturer": "LGE",
        "model": "OLED77Z2PCA",
        "report_model": "OLED77Z2PCA",
        "hardware": "alpha9gen5",
        "board": "lg8k",
        "version_id": "LGTV.2022.OLED77Z2",
        "screen_param": "7680-4320-260",
        "cast_model": "OLED77Z2PCA",
    },
    {
        "source": "lg_8k_pool.OLED88Z3PCA",
        "brand": "LG",
        "manufacturer": "LGE",
        "model": "OLED88Z3PCA",
        "report_model": "OLED88Z3PCA",
        "hardware": "alpha9gen6",
        "board": "lg8k",
        "version_id": "LGTV.2023.OLED88Z3",
        "screen_param": "7680-4320-320",
        "cast_model": "OLED88Z3PCA",
    },
    {
        "source": "lg_8k_pool.OLED77Z3PCA",
        "brand": "LG",
        "manufacturer": "LGE",
        "model": "OLED77Z3PCA",
        "report_model": "OLED77Z3PCA",
        "hardware": "alpha9gen6",
        "board": "lg8k",
        "version_id": "LGTV.2023.OLED77Z3",
        "screen_param": "7680-4320-260",
        "cast_model": "OLED77Z3PCA",
    },
    {
        "source": "lg_8k_pool.OLED88Z4PCA",
        "brand": "LG",
        "manufacturer": "LGE",
        "model": "OLED88Z4PCA",
        "report_model": "OLED88Z4PCA",
        "hardware": "alpha9gen7",
        "board": "lg8k",
        "version_id": "LGTV.2024.OLED88Z4",
        "screen_param": "7680-4320-320",
        "cast_model": "OLED88Z4PCA",
    },
    {
        "source": "lg_8k_pool.86QNED99",
        "brand": "LG",
        "manufacturer": "LGE",
        "model": "86QNED99",
        "report_model": "86QNED99",
        "hardware": "alpha9gen4",
        "board": "lg8k",
        "version_id": "LGTV.2021.86QNED99",
        "screen_param": "7680-4320-300",
        "cast_model": "86QNED99",
    },
    {
        "source": "sony_4k_pool.XR-85X95K",
        "brand": "Sony",
        "manufacturer": "Sony",
        "model": "XR-85X95K",
        "report_model": "XR85X95K",
        "hardware": "mt5895",
        "board": "mt5895",
        "version_id": "SONYTV.2022.XR_85X95K",
        "screen_param": "3840-2160-300",
        "cast_model": "XR-85X95K",
    },
    {
        "source": "sony_4k_pool.XR-75X95K",
        "brand": "Sony",
        "manufacturer": "Sony",
        "model": "XR-75X95K",
        "report_model": "XR75X95K",
        "hardware": "mt5895",
        "board": "mt5895",
        "version_id": "SONYTV.2022.XR_75X95K",
        "screen_param": "3840-2160-280",
        "cast_model": "XR-75X95K",
    },
    {
        "source": "sony_4k_pool.XR-65X90K",
        "brand": "Sony",
        "manufacturer": "Sony",
        "model": "XR-65X90K",
        "report_model": "XR65X90K",
        "hardware": "mt5895",
        "board": "mt5895",
        "version_id": "SONYTV.2022.XR_65X90K",
        "screen_param": "3840-2160-260",
        "cast_model": "XR-65X90K",
    },
    {
        "source": "sony_4k_pool.XR-55X90K",
        "brand": "Sony",
        "manufacturer": "Sony",
        "model": "XR-55X90K",
        "report_model": "XR55X90K",
        "hardware": "mt5895",
        "board": "mt5895",
        "version_id": "SONYTV.2022.XR_55X90K",
        "screen_param": "3840-2160-240",
        "cast_model": "XR-55X90K",
    },
    {
        "source": "sony_4k_pool.XR-65A95K",
        "brand": "Sony",
        "manufacturer": "Sony",
        "model": "XR-65A95K",
        "report_model": "XR65A95K",
        "hardware": "mt5895",
        "board": "mt5895",
        "version_id": "SONYTV.2022.XR_65A95K",
        "screen_param": "3840-2160-260",
        "cast_model": "XR-65A95K",
    },
    {
        "source": "samsung_4k_pool.QA85QN90C",
        "brand": "Samsung",
        "manufacturer": "Samsung",
        "model": "QA85QN90C",
        "report_model": "QA85QN90C",
        "hardware": "s5e9935",
        "board": "neo4k",
        "version_id": "SAMSUNGTV.2023.QN90C",
        "screen_param": "3840-2160-300",
        "cast_model": "QA85QN90C",
    },
    {
        "source": "samsung_4k_pool.QA75QN90C",
        "brand": "Samsung",
        "manufacturer": "Samsung",
        "model": "QA75QN90C",
        "report_model": "QA75QN90C",
        "hardware": "s5e9935",
        "board": "neo4k",
        "version_id": "SAMSUNGTV.2023.QN90C",
        "screen_param": "3840-2160-280",
        "cast_model": "QA75QN90C",
    },
    {
        "source": "samsung_4k_pool.QA65QN90C",
        "brand": "Samsung",
        "manufacturer": "Samsung",
        "model": "QA65QN90C",
        "report_model": "QA65QN90C",
        "hardware": "s5e9935",
        "board": "neo4k",
        "version_id": "SAMSUNGTV.2023.QN90C",
        "screen_param": "3840-2160-260",
        "cast_model": "QA65QN90C",
    },
    {
        "source": "samsung_4k_pool.QA55QN90C",
        "brand": "Samsung",
        "manufacturer": "Samsung",
        "model": "QA55QN90C",
        "report_model": "QA55QN90C",
        "hardware": "s5e9935",
        "board": "neo4k",
        "version_id": "SAMSUNGTV.2023.QN90C",
        "screen_param": "3840-2160-240",
        "cast_model": "QA55QN90C",
    },
    {
        "source": "samsung_4k_pool.QA65S95C",
        "brand": "Samsung",
        "manufacturer": "Samsung",
        "model": "QA65S95C",
        "report_model": "QA65S95C",
        "hardware": "s5e9935",
        "board": "oled4k",
        "version_id": "SAMSUNGTV.2023.S95C",
        "screen_param": "3840-2160-260",
        "cast_model": "QA65S95C",
    },
    {
        "source": "lg_4k_pool.OLED83C3PCA",
        "brand": "LG",
        "manufacturer": "LGE",
        "model": "OLED83C3PCA",
        "report_model": "OLED83C3PCA",
        "hardware": "alpha9gen6",
        "board": "lg4k",
        "version_id": "LGTV.2023.OLED83C3",
        "screen_param": "3840-2160-300",
        "cast_model": "OLED83C3PCA",
    },
    {
        "source": "lg_4k_pool.OLED77C3PCA",
        "brand": "LG",
        "manufacturer": "LGE",
        "model": "OLED77C3PCA",
        "report_model": "OLED77C3PCA",
        "hardware": "alpha9gen6",
        "board": "lg4k",
        "version_id": "LGTV.2023.OLED77C3",
        "screen_param": "3840-2160-280",
        "cast_model": "OLED77C3PCA",
    },
    {
        "source": "lg_4k_pool.OLED65C3PCA",
        "brand": "LG",
        "manufacturer": "LGE",
        "model": "OLED65C3PCA",
        "report_model": "OLED65C3PCA",
        "hardware": "alpha9gen6",
        "board": "lg4k",
        "version_id": "LGTV.2023.OLED65C3",
        "screen_param": "3840-2160-260",
        "cast_model": "OLED65C3PCA",
    },
    {
        "source": "lg_4k_pool.OLED55C3PCA",
        "brand": "LG",
        "manufacturer": "LGE",
        "model": "OLED55C3PCA",
        "report_model": "OLED55C3PCA",
        "hardware": "alpha9gen6",
        "board": "lg4k",
        "version_id": "LGTV.2023.OLED55C3",
        "screen_param": "3840-2160-240",
        "cast_model": "OLED55C3PCA",
    },
    {
        "source": "lg_4k_pool.86QNED90",
        "brand": "LG",
        "manufacturer": "LGE",
        "model": "86QNED90",
        "report_model": "86QNED90",
        "hardware": "alpha7gen5",
        "board": "lg4k",
        "version_id": "LGTV.2022.86QNED90",
        "screen_param": "3840-2160-300",
        "cast_model": "86QNED90",
    },
    {
        "source": "tcl_8k_pool.85X925PRO",
        "brand": "TCL",
        "manufacturer": "TCL",
        "model": "85X925 PRO",
        "report_model": "85X925PRO",
        "hardware": "mt9615",
        "board": "tcl8k",
        "version_id": "TCLTV.2021.X925PRO",
        "screen_param": "7680-4320-280",
        "cast_model": "85X925 PRO",
    },
    {
        "source": "tcl_8k_pool.75X925PRO",
        "brand": "TCL",
        "manufacturer": "TCL",
        "model": "75X925 PRO",
        "report_model": "75X925PRO",
        "hardware": "mt9615",
        "board": "tcl8k",
        "version_id": "TCLTV.2021.X925PRO",
        "screen_param": "7680-4320-260",
        "cast_model": "75X925 PRO",
    },
    {
        "source": "tcl_4k_pool.85C845",
        "brand": "TCL",
        "manufacturer": "TCL",
        "model": "85C845",
        "report_model": "85C845",
        "hardware": "mt9615",
        "board": "tcl4k",
        "version_id": "TCLTV.2023.C845",
        "screen_param": "3840-2160-300",
        "cast_model": "85C845",
    },
    {
        "source": "tcl_4k_pool.75C845",
        "brand": "TCL",
        "manufacturer": "TCL",
        "model": "75C845",
        "report_model": "75C845",
        "hardware": "mt9615",
        "board": "tcl4k",
        "version_id": "TCLTV.2023.C845",
        "screen_param": "3840-2160-280",
        "cast_model": "75C845",
    },
    {
        "source": "tcl_4k_pool.65C845",
        "brand": "TCL",
        "manufacturer": "TCL",
        "model": "65C845",
        "report_model": "65C845",
        "hardware": "mt9615",
        "board": "tcl4k",
        "version_id": "TCLTV.2023.C845",
        "screen_param": "3840-2160-260",
        "cast_model": "65C845",
    },
    {
        "source": "tcl_4k_pool.75C745",
        "brand": "TCL",
        "manufacturer": "TCL",
        "model": "75C745",
        "report_model": "75C745",
        "hardware": "mt9615",
        "board": "tcl4k",
        "version_id": "TCLTV.2023.C745",
        "screen_param": "3840-2160-280",
        "cast_model": "75C745",
    },
    {
        "source": "tcl_4k_pool.65C745",
        "brand": "TCL",
        "manufacturer": "TCL",
        "model": "65C745",
        "report_model": "65C745",
        "hardware": "mt9615",
        "board": "tcl4k",
        "version_id": "TCLTV.2023.C745",
        "screen_param": "3840-2160-260",
        "cast_model": "65C745",
    },
    {
        "source": "changhong_4k_pool.U65G7",
        "brand": "CHANGHONG",
        "manufacturer": "CHANGHONG",
        "model": "U65G7",
        "report_model": "U65G7",
        "hardware": "mt9632",
        "board": "changhong4k",
        "version_id": "CHANGHONGTV.2022.U65G7",
        "screen_param": "3840-2160-260",
        "cast_model": "U65G7",
    },
    {
        "source": "changhong_4k_pool.U55G7",
        "brand": "CHANGHONG",
        "manufacturer": "CHANGHONG",
        "model": "U55G7",
        "report_model": "U55G7",
        "hardware": "mt9632",
        "board": "changhong4k",
        "version_id": "CHANGHONGTV.2022.U55G7",
        "screen_param": "3840-2160-240",
        "cast_model": "U55G7",
    },
    {
        "source": "changhong_4k_pool.L55QCN1",
        "brand": "CHANGHONG",
        "manufacturer": "CHANGHONG",
        "model": "L55QCN1",
        "report_model": "L55QCN1",
        "hardware": "mt9632",
        "board": "changhong4k",
        "version_id": "CHANGHONGTV.2021.L55QCN1",
        "screen_param": "3840-2160-240",
        "cast_model": "L55QCN1",
    },
    {
        "source": "changhong_4k_pool.U43QCN1",
        "brand": "CHANGHONG",
        "manufacturer": "CHANGHONG",
        "model": "U43QCN1",
        "report_model": "U43QCN1",
        "hardware": "mt9632",
        "board": "changhong4k",
        "version_id": "CHANGHONGTV.2021.U43QCN1",
        "screen_param": "3840-2160-220",
        "cast_model": "U43QCN1",
    },
    {
        "source": "changhong_4k_pool.UD65YC5500UA",
        "brand": "CHANGHONG",
        "manufacturer": "CHANGHONG",
        "model": "UD65YC5500UA",
        "report_model": "UD65YC5500UA",
        "hardware": "mt9632",
        "board": "changhong4k",
        "version_id": "CHANGHONGTV.2020.UD65YC5500UA",
        "screen_param": "3840-2160-260",
        "cast_model": "UD65YC5500UA",
    },
]


def random_device_template() -> dict:
    return secrets.choice(DEVICE_PROFILE_POOL)


def device_profile_from_template(
    template: dict, android_id: str, mac: str
) -> DeviceProfile:
    brand_id = sanitize_profile_id(template["brand"])
    model_id = sanitize_profile_id(template["model"])
    device = f"{brand_id}_{model_id}"
    product = f"{brand_id}_{model_id}"
    return DeviceProfile(
        android_id=android_id,
        mac=mac,
        hardware=template["hardware"],
        board=template["board"],
        brand=template["brand"],
        device=device,
        manufacturer=template["manufacturer"],
        model=template["model"],
        product=product,
        tags="release-keys",
        build_type="user",
        user="build",
        resolution=resolution_from_screen_param(template["screen_param"]),
        display=f"{template['model']}-user 13 {template['version_id']} 2024 release-keys",
        version_id=template["version_id"],
        host=f"{brand_id}-tv-build",
        fingerprint=(
            f"{template['manufacturer']}/{product}/{device}:13/"
            f"{template['version_id']}/2024:user/release-keys"
        ),
        report_model=template["report_model"],
    )


def default_device_state() -> DeviceState:
    template = random_device_template()
    profile = device_profile_from_template(
        template, random_hex_string(16), random_mac_address()
    )
    return DeviceState(
        schema_version=1,
        profile_source=template["source"],
        profile=profile,
        screen_param=template["screen_param"],
        cast_model=template["cast_model"],
        x_uid=compute_x_uid(profile),
        cloud_guid="",
        registered_at=0.0,
        updated_at=now_f64(),
    )


def load_device_state(path: str):
    try:
        with open(path, encoding="utf-8") as f:
            text = f.read()
    except OSError:
        return default_device_state(), False
    try:
        data = json.loads(text)
    except ValueError:
        return default_device_state(), False
    try:
        profile = DeviceProfile.from_dict(data.get("profile", {}))
        state = DeviceState(
            schema_version=int(data.get("schema_version", 1)),
            profile_source=str(data.get("profile_source", "")),
            profile=profile,
            screen_param=str(data.get("screen_param", "")),
            cast_model=str(data.get("cast_model", "")),
            x_uid=str(data.get("x_uid", "")),
            cloud_guid=str(data.get("cloud_guid", "")),
            registered_at=float(data.get("registered_at", 0.0)),
            updated_at=float(data.get("updated_at", 0.0)),
        )
    except (ValueError, TypeError, AttributeError):
        return default_device_state(), False
    if len(state.profile.android_id) != 16 or not state.profile.mac:
        return default_device_state(), False
    state.x_uid = compute_x_uid(state.profile)
    if not state.screen_param:
        state.screen_param = "7680-4320-280"
    if not state.cast_model:
        state.cast_model = state.profile.model
    return state, True


def save_device_state(path: str, state: DeviceState) -> None:
    parent = os.path.dirname(os.path.abspath(path))
    if parent:
        os.makedirs(parent, exist_ok=True)
    with open(path, "w", encoding="utf-8") as f:
        f.write(
            json.dumps(
                dataclasses.asdict(state), indent=2, ensure_ascii=False, sort_keys=True
            )
            + "\n"
        )


def infer_os_version(profile: DeviceProfile) -> str:
    if ":" in profile.fingerprint:
        tail = profile.fingerprint.split(":", 1)[1]
        if "/" in tail:
            return tail.split("/", 1)[0]
    return ""


def infer_sdk_int(profile: DeviceProfile) -> str:
    major = infer_os_version(profile).split(".")[0] if infer_os_version(profile) else ""
    return {
        "13": "33",
        "12": "31",
        "11": "30",
        "10": "29",
        "9": "28",
        "8": "26",
        "7": "24",
        "6": "23",
    }.get(major, "")


def compute_x_uid(profile: DeviceProfile) -> str:
    build_identity_str = (
        "1698"
        + profile.hardware
        + profile.board
        + profile.brand
        + profile.device
        + profile.manufacturer
        + profile.model
        + profile.product
        + profile.tags
        + profile.build_type
        + profile.user
        + profile.resolution
        + profile.mac
    )
    uuid_part = java_uuid_from_hashes(
        java_string_hashcode(build_identity_str),
        java_string_hashcode(profile.model),
    )
    return sha1_upper(f"{profile.android_id}|{uuid_part}")


def build_identity(profile: DeviceProfile, app_channel: str, version: str) -> Identity:
    x_uid = compute_x_uid(profile)
    x_fingerprint, ts, _day0 = compute_fingerprint(x_uid, current_time_ms())
    headers = {
        "Accept": "application/json",
        "Accept-Language": DEFAULT_ACCEPT_LANGUAGE,
        "Referer": "api.cctv.cn",
        "User-Agent": "cctv_app_tv",
        "UID": profile.android_id,
        "appChannel": app_channel,
        "X-Uid": x_uid,
        "X-Fingerprint": x_fingerprint,
        "X-Version": version,
        "Content-Type": "application/json; charset=utf-8",
        "Connection": "Keep-Alive",
        "Accept-Encoding": "gzip",
        "Cache-Control": "no-cache",
    }
    return Identity(
        x_uid=x_uid,
        x_fingerprint=x_fingerprint,
        fingerprint_timestamp_ms=ts,
        headers=headers,
    )


def next_request_timestamp_ms() -> int:
    return current_time_ms()


def fresh_headers(
    template: dict, content_type: str, accept=None, force_ts=None
) -> dict:
    headers = {}
    if accept is not None:
        headers["Accept"] = accept
    headers["X-Timestamp"] = str(
        force_ts if force_ts is not None else next_request_timestamp_ms()
    )
    headers["X-Nonce"] = str(uuid.uuid4())
    for key in (
        "Accept-Language",
        "Referer",
        "User-Agent",
        "UID",
        "appChannel",
        "X-Uid",
        "X-Fingerprint",
        "X-Version",
    ):
        if key in template:
            headers[key] = template[key]
    headers["Content-Type"] = content_type
    for key in ("Connection", "Accept-Encoding", "Cache-Control"):
        if key in template:
            headers[key] = template[key]
    return headers


def compact_json_bytes(value, escape_forward_slashes: bool) -> bytes:
    text = json.dumps(value, separators=(",", ":"), ensure_ascii=False, sort_keys=True)
    if escape_forward_slashes:
        text = text.replace("/", "\\/")
    return text.encode("utf-8")


def normalize_aes_key(value: str) -> bytes:
    raw = value.encode("utf-8")
    return (raw + b"\x00" * 32)[:32]


def aes_gcm_decrypt_b64(value: str, key: str) -> str:
    try:
        raw = base64.b64decode(value, validate=True)
    except (binascii.Error, ValueError) as e:
        raise YsptpError(f"base64 decode failed: {e}")
    if len(raw) <= 12:
        raise YsptpError("AES-GCM payload too short")
    try:
        plain = aes_gcm_decrypt(normalize_aes_key(key), raw[:12], raw[12:])
    except ValueError:
        raise YsptpError("AES-GCM decrypt failed")
    try:
        return plain.decode("utf-8")
    except UnicodeDecodeError as e:
        raise YsptpError(f"AES-GCM plaintext is not UTF-8: {e}")


def aes_gcm_encrypt_b64(value: str, key: str) -> str:
    nonce = secrets.token_bytes(12)
    try:
        encrypted = aes_gcm_encrypt(
            normalize_aes_key(key), nonce, value.encode("utf-8")
        )
    except ValueError:
        raise YsptpError("AES-GCM encrypt failed")
    return base64.b64encode(nonce + encrypted).decode("ascii")


def rsa_encrypt_device_id(device_id: str) -> str:
    try:
        der = base64.b64decode(RSA_PUBLIC_KEY_B64, validate=True)
    except (binascii.Error, ValueError) as e:
        raise YsptpError(f"RSA public key base64 decode failed: {e}")
    n, e = parse_spki_rsa_pubkey(der)
    k = (n.bit_length() + 7) // 8
    hlen = 32  # SHA-256
    chunk_size = k - 2 * hlen - 2  # 190 for a 2048-bit key
    out = bytearray()
    data = device_id.encode("utf-8")
    for i in range(0, len(data), chunk_size):
        chunk = data[i : i + chunk_size]
        out += rsa_oaep_sha256_encrypt(der, chunk, secrets.token_bytes(hlen))
    return base64.b64encode(bytes(out)).decode("ascii")


def report_model_from_build(profile: DeviceProfile) -> str:
    return profile.model.replace(profile.manufacturer, "").replace(" ", "")


def app_start_field(value, limit: int) -> str:
    return str(value)[:limit] if limit >= 0 else str(value)


def build_report_common_value(
    profile: DeviceProfile,
    x_uid: str,
    app_channel: str,
    version: str,
    sdk_version: str,
    data_time_ms: int,
) -> dict:
    model = profile.report_model or report_model_from_build(profile)
    return {
        "cctv_id": app_start_field(x_uid, 64),
        "device_id": app_start_field(profile.android_id, 64),
        "idfa": "",
        "idfv": "",
        "user_id": "",
        "app_key": app_start_field(REPORT_APP_KEY, 64),
        "imei": "",
        "android_id": app_start_field(profile.android_id, 64),
        "mac": app_start_field(profile.mac, 64),
        "device_builder_type": app_start_field(profile.build_type, 64),
        "device_hardware": app_start_field(profile.hardware, 64),
        "device_board": app_start_field(profile.board, 64),
        "device_brand": app_start_field(profile.brand, 64),
        "device_params": app_start_field(profile.device, 64),
        "device_display": app_start_field(profile.display, 64),
        "device_version_id": app_start_field(profile.version_id, 64),
        "device_host": app_start_field(profile.host, 128),
        "device_product": app_start_field(profile.product, 64),
        "device_tags": app_start_field(profile.tags, 64),
        "device_user": app_start_field(profile.user, 30),
        "device_fingerprint": app_start_field(profile.fingerprint, 128),
        "device_manufacturer": app_start_field(profile.manufacturer, 64),
        "device_model": app_start_field(model, 50),
        "device_resolution": app_start_field(profile.resolution, 20),
        "system_type": "Android",
        "device_type": "TV",
        "app_language": "CHINESE",
        "app_version": app_start_field(version, 30),
        "sdk_version": app_start_field(sdk_version, 30),
        "os_version": app_start_field(infer_os_version(profile), 20),
        "app_channel": app_start_field(app_channel, 50),
        "data_time": app_start_field(data_time_ms, 13),
    }


def build_app_start_body(
    profile: DeviceProfile,
    x_uid: str,
    app_channel: str,
    version: str,
    data_time_ms: int,
) -> dict:
    return {
        "key": "app_start_d1",
        "value": build_report_common_value(
            profile, x_uid, app_channel, version, "", data_time_ms
        ),
    }


def build_collect_headers(profile: DeviceProfile) -> dict:
    release = infer_os_version(profile)
    return {
        "Content-type": "application/x-www-form-urlencoded",
        "Charset": "UTF-8",
        "User-Agent": (
            "Dalvik/2.1.0 (Linux; U; Android "
            + (release if release else "Android")
            + f"; {profile.model} Build/{profile.version_id})"
        ),
        "Connection": "Keep-Alive",
        "Accept-Encoding": "gzip",
    }


def parse_result_code(value) -> int | None:
    if isinstance(value, dict):
        for key in ("result", "code", "errCode", "errcode", "ret"):
            if key in value:
                raw = value[key]
                if isinstance(raw, bool):
                    continue
                if isinstance(raw, int):
                    return raw
                if isinstance(raw, str):
                    try:
                        return int(raw)
                    except ValueError:
                        pass
        for key in ("data", "error", "response"):
            if key in value:
                found = parse_result_code(value[key])
                if found is not None:
                    return found
    return None


def extract_guid(value) -> str:
    if isinstance(value, dict):
        data = value.get("data")
        if isinstance(data, dict):
            guid = data.get("guid")
            if isinstance(guid, str):
                return guid
    return ""


def root_headers(version: str) -> dict:
    return {
        "X-Uid": "ROOT",
        "X-Fingerprint": "ROOT",
        "X-Nonce": str(uuid.uuid4()),
        "X-Timestamp": str(next_request_timestamp_ms()),
        "X-Version": version,
        "UID": "ROOT",
        "Referer": "api.cctv.cn",
        "User-Agent": "cctv_app_tv",
        "appChannel": "ROOT",
        "Connection": "Keep-Alive",
        "Accept-Encoding": "gzip",
    }


def build_vdn_appcommon(version: str) -> str:
    return json.dumps(
        {"adid": "", "av": version, "an": VDN_APP_NAME, "ap": "cctv_app_tv"},
        separators=(",", ":"),
        ensure_ascii=False,
        sort_keys=True,
    )


def url_host(url: str) -> str:
    try:
        return urllib.parse.urlsplit(url).hostname or ""
    except ValueError:
        return ""


def live_playback_host_needs_signed_headers(host: str) -> bool:
    lower = host.lower()
    return "liveali" in lower or "liveten" in lower


def default_cctv_playback_headers(uid: str) -> dict:
    return {
        "UID": uid,
        "APPID": AK,
        "Referer": "api.cctv.cn",
        "User-Agent": "cctv_app_tv",
    }


def cctv_playback_headers_for_entry(entry: ChannelEntry) -> dict:
    headers = default_cctv_playback_headers(entry.android_id)
    for key in ("UID", "APPID", "APPRANDOMSTR", "Referer", "User-Agent", "APPSIGN"):
        value = entry.playback_headers.get(key)
        if value:
            headers[key] = value
    return headers


def entry_missing_signed_playback_headers(entry: ChannelEntry) -> bool:
    host = entry.final_host or url_host(entry.final_url)
    if not live_playback_host_needs_signed_headers(host):
        return False
    for key in ("APPID", "APPSIGN", "APPRANDOMSTR"):
        value = entry.playback_headers.get(key, "")
        if not value.strip():
            return True
    return False


def generate_app_random_str() -> str:
    return (
        f"{secrets.randbits(32):08x}-0000-"
        f"{secrets.randbits(32) & 0xFFFF:04x}-0000-"
        f"00000000{secrets.randbits(32) & 0xFFFF:04x}"
    )


def compute_vdn_code(app_secret: str, random_str=None):
    r = random_str if random_str is not None else generate_app_random_str()
    return md5_hex(f"{AK}{app_secret}{r}"), r


def form_urlencode_value(s: str) -> str:
    """WHATWG application/x-www-form-urlencoded value encoding.

    Mirrors serde_urlencoded: everything except [A-Za-z0-9] and ``*-._``
    is percent-encoded (uppercase hex, UTF-8), space becomes ``+``.
    """
    out = []
    for byte in s.encode("utf-8"):
        ch = chr(byte)
        if ch.isascii() and (ch.isalnum() or ch in "*-._"):
            out.append(ch)
        elif byte == 0x20:
            out.append("+")
        else:
            out.append(f"%{byte:02X}")
    return "".join(out)


def form_encode(pairs) -> bytes:
    return "&".join(
        f"{form_urlencode_value(k)}={form_urlencode_value(v)}" for k, v in pairs
    ).encode("utf-8")


def _normalize_network_error(e: Exception) -> str:
    """Describe transport errors without including request URLs."""
    if isinstance(e, ConnectionRefusedError):
        return f"connection refused: {e}"
    if isinstance(e, ConnectionResetError):
        return f"connection reset by peer: {e}"
    if isinstance(e, (socket.timeout, TimeoutError)):
        return f"operation timed out: {e}"
    if isinstance(e, socket.gaierror):
        return f"failed to lookup address: {e}"
    if isinstance(e, urllib.error.URLError):
        reason = e.reason
        if isinstance(reason, Exception):
            return _normalize_network_error(reason)
        return f"network error: {e}"
    return f"network error: {e}"


class HttpResponse:
    def __init__(self, status: int, reason: str, headers: dict, body: bytes):
        self.status = status
        self.reason = reason
        self.headers = headers  # lower-cased keys
        self.body = body

    def text(self) -> str:
        return self.body.decode("utf-8", errors="replace")


class HttpClient:
    """Blocking HTTP client with cookie jar, timeout and TLS options.

    Replaces reqwest::blocking::Client.  gzip responses are transparently
    decoded (reqwest was built with the ``gzip`` feature).
    """

    def __init__(self, timeout: float, insecure_tls: bool):
        self._timeout = max(timeout, 0.1)
        if insecure_tls:
            self._ctx = ssl._create_unverified_context()
        else:
            self._ctx = ssl.create_default_context()
        jar = http.cookiejar.CookieJar()
        https_handler = urllib.request.HTTPSHandler(context=self._ctx)
        self._opener = urllib.request.build_opener(
            urllib.request.HTTPCookieProcessor(jar),
            https_handler,
        )
        self._jar = jar

    def _send(
        self, method: str, url: str, headers: dict, data: bytes | None
    ) -> HttpResponse:
        req = urllib.request.Request(url, data=data, method=method)
        for k, v in headers.items():
            # urllib skips empty values on some paths; force them through.
            req.add_header(k, v)
        try:
            try:
                with self._opener.open(req, timeout=self._timeout) as resp:
                    status = resp.status
                    reason = resp.reason or ""
                    hdrs = {k.lower(): v for k, v in resp.headers.items()}
                    body = resp.read()
            except urllib.error.HTTPError as e:
                status = e.code
                reason = e.reason or ""
                try:
                    hdrs = (
                        {k.lower(): v for k, v in e.headers.items()}
                        if e.headers
                        else {}
                    )
                except Exception:
                    hdrs = {}
                try:
                    body = e.read()
                except Exception:
                    body = b""
        except Exception as e:
            raise YsptpError(_normalize_network_error(e))
        if "gzip" in hdrs.get("content-encoding", "").lower():
            try:
                body = gzip.decompress(body)
            except (OSError, EOFError):
                pass
        return HttpResponse(status, reason, hdrs, body)

    def get(self, url: str, headers: dict) -> HttpResponse:
        return self._send("GET", url, headers, None)

    def post_bytes(self, url: str, headers: dict, data: bytes) -> HttpResponse:
        return self._send("POST", url, headers, data)

    def post_json(self, url: str, headers: dict, body) -> HttpResponse:
        data = json.dumps(
            body, separators=(",", ":"), ensure_ascii=False, sort_keys=True
        ).encode("utf-8")
        return self._send("POST", url, headers, data)

    def post_form(self, url: str, headers: dict, pairs) -> HttpResponse:
        return self._send("POST", url, headers, form_encode(pairs))


def response_json(resp: HttpResponse):
    status = resp.status
    text = resp.text()
    try:
        value = json.loads(text)
    except ValueError:
        value = None
    return status, text, value


def http_status_text(status: int, reason: str) -> str:
    return f"{status} {reason}".strip() if reason else str(status)


class ResolverState:
    def __init__(self):
        self.cache: dict[str, ChannelEntry] = {}
        self.background_refreshing: dict[str, float] = {}
        self.generation = 0
        self.session_generation = 0
        self.app_session = None  # AppSession | None
        self.last_control_request_at = 0.0
        self.last_business_end_at = 0.0
        self.refreshing_channel = ""
        self.last_error = ""
        self.last_error_at = 0.0
        self.ad_display = False


@dataclasses.dataclass
class AppSession:
    profile: DeviceProfile
    identity: Identity
    client: HttpClient
    session_key: str
    cloud_guid: str
    version: str
    screen_param: str
    cast_model: str
    created_at: float
    generation: int
    last_heartbeat_at: float
    heartbeat_count: int
    last_heartbeat_result: str
    last_heartbeat_error: str


class RefreshQueue:
    def __init__(self):
        self.cond = threading.Condition()
        self.queued: collections.deque[str] = collections.deque()
        self.queued_channels: dict[str, float] = {}
        self.running_channel = ""
        self.running_started_at = 0.0
        self.enqueued_total = 0
        self.dropped_total = 0
        self.completed_total = 0
        self.failed_total = 0
        self.last_enqueued_at = 0.0
        self.last_finished_at = 0.0
        self.last_dropped_at = 0.0
        self.last_drop_reason = ""


@dataclasses.dataclass
class DeviceConfig:
    device_json: str
    cache_ttl: float = 600.0
    stale_while_refresh_ttl: float = 120.0
    refresh_error_cooldown: float = 30.0
    background_refresh_queue_limit: int = 4
    refresh_interval: float = 2.0
    control_step_jitter_min_ms: int = 0
    control_step_jitter_max_ms: int = 0
    heartbeat_interval: float = 30.0
    heartbeat_ttl_guard: float = 60.0
    session_ttl: float = 7200.0
    timeout: float = 15.0


def advertised_rate(label):
    number = re.fullmatch(r"(\d{1,3})p", str(label), re.I)
    return int(number[1]) if number else 0


class Resolver:
    def __init__(self, args: DeviceConfig):
        self.args = args
        self.generic_client = HttpClient(args.timeout, False)
        self.state = ResolverState()
        self.state_lock = threading.Lock()
        self.control_lock = threading.Lock()
        self.refresh_queue = RefreshQueue()

    def start_heartbeat(self):
        def loop():
            while True:
                time.sleep(max(self.args.heartbeat_interval, 0.0))
                try:
                    self.send_heartbeat()
                except Exception:
                    pass

        t = threading.Thread(target=loop, daemon=True, name="heartbeat")
        t.start()

    def start_refresh_worker(self):
        t = threading.Thread(
            target=self.refresh_worker_loop, daemon=True, name="refresh-worker"
        )
        t.start()

    def enqueue_background_refresh(self, channel: str):
        now = now_f64()
        q = self.refresh_queue
        with q.cond:
            if q.running_channel == channel or channel in q.queued_channels:
                return "already_active", ""
            limit = int(self.args.background_refresh_queue_limit)
            if limit == 0 or len(q.queued) >= limit:
                q.dropped_total += 1
                q.last_dropped_at = now
                if limit == 0:
                    q.last_drop_reason = (
                        f"background refresh queue disabled; channel={channel}"
                    )
                else:
                    q.last_drop_reason = (
                        f"background refresh queue full ({len(q.queued)}/{limit}); "
                        f"channel={channel}"
                    )
                return "rejected", q.last_drop_reason
            q.queued.append(channel)
            q.queued_channels[channel] = now
            q.enqueued_total += 1
            q.last_enqueued_at = now
            q.cond.notify()
            return "enqueued", ""

    def refresh_worker_loop(self):
        q = self.refresh_queue
        while True:
            with q.cond:
                while not q.queued:
                    q.cond.wait()
                channel = q.queued.popleft()
                q.queued_channels.pop(channel, None)
                q.running_channel = channel
                q.running_started_at = now_f64()
            ok = self.refresh_channel_background(channel)
            with q.cond:
                q.running_channel = ""
                q.running_started_at = 0.0
                q.last_finished_at = now_f64()
                if ok:
                    q.completed_total += 1
                else:
                    q.failed_total += 1

    @contextlib.contextmanager
    def control_request_slot(self, _label: str):
        min_interval = max(0.0, float(self.args.refresh_interval))
        while True:
            with self.state_lock:
                last = self.state.last_control_request_at
                wait = 0.0 if last <= 0.0 else min_interval - (now_f64() - last)
            if wait <= 0.0:
                break
            time.sleep(wait)
        jitter = self.control_step_jitter_duration()
        if jitter is not None:
            time.sleep(jitter)
        try:
            yield
        finally:
            with self.state_lock:
                self.state.last_control_request_at = now_f64()

    def control_step_jitter_duration(self):
        min_ms = int(self.args.control_step_jitter_min_ms)
        max_ms = int(self.args.control_step_jitter_max_ms)
        if max_ms == 0:
            return None
        upper = max(max_ms, min_ms)
        span = upper - min_ms
        extra = secrets.randbelow(span + 1) if span else 0
        return (min_ms + extra) / 1000.0

    def app_session_fresh(self, sess: AppSession) -> bool:
        return float(self.args.session_ttl) <= 0.0 or (
            now_f64() - sess.created_at
        ) < float(self.args.session_ttl)

    def app_session_ttl_remaining(self, sess: AppSession):
        if float(self.args.session_ttl) <= 0.0:
            return None
        return float(self.args.session_ttl) - (now_f64() - sess.created_at)

    def ensure_channel(self, channel: str) -> ChannelEntry:
        now = now_f64()
        with self.state_lock:
            entry = self.state.cache.get(channel)
            if entry is not None:
                if entry.fresh(now) and not entry_missing_signed_playback_headers(
                    entry
                ):
                    return entry
                if entry.stale_usable(
                    now, float(self.args.stale_while_refresh_ttl)
                ) and not entry_missing_signed_playback_headers(entry):
                    retry_at = entry.last_refresh_failed_at + float(
                        self.args.refresh_error_cooldown
                    )
                    started = self.state.background_refreshing.get(channel)
                    should_refresh = now >= retry_at and (
                        started is None or now - started > 300.0
                    )
                    clone = entry
                    if should_refresh:
                        self.state.background_refreshing[channel] = now
                        status, reason = self.enqueue_background_refresh(channel)
                        if status == "rejected":
                            self.state.background_refreshing.pop(channel, None)
                            e2 = self.state.cache.get(channel)
                            if e2 is not None:
                                e2.last_refresh_error = reason
                                e2.last_refresh_failed_at = now
                    return clone

        with self.control_lock:
            now = now_f64()
            with self.state_lock:
                entry = self.state.cache.get(channel)
                if (
                    entry is not None
                    and entry.fresh(now)
                    and not entry_missing_signed_playback_headers(entry)
                ):
                    return entry
            try:
                entry = self.refresh_channel_controlled(channel)
            except YsptpError as err:
                err_text = str(err)
                with self.state_lock:
                    self.state.last_error = err_text
                    self.state.last_error_at = now_f64()
                    last_error = self.state.last_error
                    last_error_at = self.state.last_error_at
                    entry = self.state.cache.get(channel)
                    if entry is not None and entry.final_url:
                        entry.last_refresh_error = last_error
                        entry.last_refresh_failed_at = last_error_at
                        clone = entry
                    else:
                        clone = None
                if clone is None:
                    raise
                return clone
            return entry

    def refresh_channel_background(self, channel: str) -> bool:
        try:
            with self.control_lock:
                now = now_f64()
                with self.state_lock:
                    entry = self.state.cache.get(channel)
                    if (
                        entry is not None
                        and entry.fresh(now)
                        and not entry_missing_signed_playback_headers(entry)
                    ):
                        return True
                self.refresh_channel_controlled(channel)
            ok = True
        except YsptpError as err:
            err_text = str(err)
            with self.state_lock:
                self.state.last_error = err_text
                self.state.last_error_at = now_f64()
                last_error = self.state.last_error
                last_error_at = self.state.last_error_at
                entry = self.state.cache.get(channel)
                if entry is not None:
                    entry.last_refresh_error = last_error
                    entry.last_refresh_failed_at = last_error_at
                if is_session_invalidating_error(err_text):
                    self.state.app_session = None
            ok = False
        with self.state_lock:
            self.state.background_refreshing.pop(channel, None)
        return ok

    def refresh_channel_controlled(self, channel: str) -> ChannelEntry:
        with self.state_lock:
            wait = float(self.args.refresh_interval) - (
                now_f64() - self.state.last_business_end_at
            )
        if wait > 0.0:
            time.sleep(wait)
        with self.state_lock:
            self.state.refreshing_channel = channel
            self.state.generation += 1
            generation = self.state.generation
        log_program_fetching()
        try:
            app_session = self.get_app_session_controlled()
            live_id = channel_by_name(channel)
            if live_id is None:
                raise YsptpError(f"unknown channel {channel}")
            entry = self.resolve_channel_once(app_session, channel, live_id, generation)
        except YsptpError as err:
            with self.state_lock:
                self.state.last_business_end_at = now_f64()
                self.state.refreshing_channel = ""
                if is_session_invalidating_error(str(err)):
                    self.state.app_session = None
            raise
        with self.state_lock:
            self.state.last_business_end_at = now_f64()
            self.state.refreshing_channel = ""
            self.state.cache[channel] = entry
            self.state.last_error = ""
            log_channel_ready(channel)
        return entry

    def get_app_session_controlled(self) -> AppSession:
        with self.state_lock:
            sess = self.state.app_session
            if sess is not None and self.app_session_fresh(sess):
                return sess
            self.state.app_session = None
        with self.state_lock:
            self.state.session_generation += 1
            gen = self.state.session_generation
        sess = self.bootstrap_session(gen)
        with self.state_lock:
            self.state.app_session = sess
        return sess

    def new_ytpaddr_client(self) -> HttpClient:
        return HttpClient(float(self.args.timeout), False)

    def bootstrap_session(self, generation: int) -> AppSession:
        device_state, existed = load_device_state(self.args.device_json)
        if not existed:
            device_state.updated_at = now_f64()
            try:
                save_device_state(self.args.device_json, device_state)
            except OSError:
                pass
        profile = device_state.profile
        app_channel = "dangbei"
        version = "1.4.1"
        identity = build_identity(profile, app_channel, version)
        device_state.x_uid = identity.x_uid
        client = self.new_ytpaddr_client()
        page_session_id = str(uuid.uuid4())

        with self.control_request_slot("collect_report_start"):
            self.collect_report(
                profile,
                {
                    "key": "app_start_d1",
                    "value": build_report_common_value(
                        profile,
                        identity.x_uid,
                        app_channel,
                        version,
                        COLLECT_SDK_VERSION,
                        current_time_ms(),
                    ),
                },
            )
        self.dictionary_obtain(version)
        app_start = self.app_start_flow(client, profile, identity, app_channel, version)
        session_key = app_start.session_key

        # The app/start payload above is sent as raw bytes; the app_start
        # event below follows immediately after, same fields, no extra call.
        try:
            self.app_event_flow(profile, identity, app_channel, version)
        except YsptpError:
            pass

        with self.control_request_slot("collect_report_page"):
            page_end_time_ms = current_time_ms()
            page_start_time_ms = page_end_time_ms - 1000
            page_value = build_report_common_value(
                profile, identity.x_uid, app_channel, version, "", page_end_time_ms + 2
            )
            page_value["start_time"] = str(page_start_time_ms)
            page_value["end_time"] = str(page_end_time_ms)
            page_value["duration"] = str(page_end_time_ms - page_start_time_ms)
            page_value["page_name"] = DEFAULT_PAGE_NAME
            page_value["session_id"] = page_session_id
            page_value["network_type"] = "WIFI"
            try:
                self.collect_report(profile, {"key": "page_d1", "value": page_value})
            except YsptpError:
                pass
            page_times = (page_start_time_ms, page_end_time_ms)
        try:
            self.page_event_flow(
                profile,
                identity,
                app_channel,
                version,
                page_session_id,
                page_times[0],
                page_times[1],
            )
        except YsptpError:
            pass

        try:
            cloud_guid = self.cloud_registration_flow(identity, identity.x_uid)
        except YsptpError:
            cloud_guid = ""
        now = now_f64()
        device_state.x_uid = identity.x_uid
        device_state.updated_at = now
        if cloud_guid:
            device_state.cloud_guid = cloud_guid
            if device_state.registered_at <= 0.0:
                device_state.registered_at = now
        try:
            save_device_state(self.args.device_json, device_state)
        except OSError:
            pass
        if cloud_guid:
            try:
                self.device_info_report_flow(
                    profile, identity, app_channel, version, cloud_guid
                )
            except YsptpError:
                pass
        hb = self.heartbeat_flow(profile, identity, app_channel, version, cloud_guid)
        self.index_flow(client, identity, app_channel)
        self.warmup_flow(client, identity, version)

        return AppSession(
            profile=profile,
            identity=identity,
            client=client,
            session_key=session_key,
            cloud_guid=cloud_guid,
            version=version,
            screen_param=device_state.screen_param,
            cast_model=device_state.cast_model,
            created_at=now_f64(),
            generation=generation,
            last_heartbeat_at=now_f64(),
            heartbeat_count=1,
            last_heartbeat_result=hb,
            last_heartbeat_error="",
        )

    def collect_report(self, profile: DeviceProfile, body: dict) -> None:
        headers = build_collect_headers(profile)
        resp = self.generic_client.post_form(
            COLLECT_REPORT_URL,
            headers,
            [
                (
                    "info",
                    json.dumps(
                        body, separators=(",", ":"), ensure_ascii=False, sort_keys=True
                    ),
                )
            ],
        )
        if not 200 <= resp.status < 300:
            raise YsptpError(
                f"collect report HTTP {http_status_text(resp.status, resp.reason)}"
            )

    def dictionary_obtain(self, version: str) -> None:
        with self.control_request_slot("dictionary_obtain"):
            resp = self.generic_client.post_bytes(
                DICTIONARY_URL, root_headers(version), b""
            )
        if not 200 <= resp.status < 300:
            raise YsptpError(
                f"dictionary HTTP {http_status_text(resp.status, resp.reason)}"
            )

    def app_start_flow(
        self,
        client: HttpClient,
        profile: DeviceProfile,
        identity: Identity,
        app_channel: str,
        version: str,
    ) -> AppStartResult:
        with self.control_request_slot("app_start"):
            token_time = current_time_ms()
            xfp, ts, _day0 = compute_fingerprint(identity.x_uid, token_time)
            identity.x_fingerprint = xfp
            identity.fingerprint_timestamp_ms = ts
            identity.headers["X-Fingerprint"] = xfp
            body = build_app_start_body(
                profile, identity.x_uid, app_channel, version, current_time_ms()
            )
            payload = compact_json_bytes(body, True)
            headers = fresh_headers(
                identity.headers, "application/json", "application/json", ts
            )
            headers["UID"] = ""
            resp = client.post_bytes(APP_START_URL, headers, payload)
            status, text, value = response_json(resp)
            if 200 <= status < 300:
                data = value.get("data") if isinstance(value, dict) else None
                encrypted = ""
                if isinstance(data, dict):
                    key_val = data.get("key", data)
                    encrypted = key_val if isinstance(key_val, str) else ""
                elif isinstance(data, str):
                    encrypted = data
                if encrypted:
                    session_key = aes_gcm_decrypt_b64(encrypted, xfp[:32])
                    return AppStartResult(session_key=session_key)
            raise YsptpError(f"app/start HTTP {status}")

    def app_event_flow(
        self, profile: DeviceProfile, identity: Identity, app_channel: str, version: str
    ) -> None:
        with self.control_request_slot("app_event"):
            event_time = current_time_ms()
            value = build_report_common_value(
                profile, identity.x_uid, app_channel, version, "", event_time
            )
            value["event_id"] = "app_start"
            value["event_name"] = "应用启动"
            value["event_time"] = str(event_time)
            value["network_type"] = "WIFI"
            value["cur_version"] = version
            value["channel"] = app_channel
            value["pre_version"] = version
            body = {"key": "event", "value": value}
            headers = fresh_headers(
                identity.headers, "application/json", "application/json", None
            )
            headers["UID"] = ""
            resp = self.generic_client.post_json(REPORT_SINGLE_URL, headers, body)
            if not 200 <= resp.status < 300:
                raise YsptpError(
                    f"app event HTTP {http_status_text(resp.status, resp.reason)}"
                )

    def page_event_flow(
        self,
        profile: DeviceProfile,
        identity: Identity,
        app_channel: str,
        version: str,
        session_id: str,
        start_ms: int,
        end_ms: int,
    ) -> None:
        with self.control_request_slot("page_event"):
            value = build_report_common_value(
                profile, identity.x_uid, app_channel, version, "", end_ms + 2
            )
            value["start_time"] = str(start_ms)
            value["end_time"] = str(end_ms)
            value["duration"] = str(max(0, end_ms - start_ms))
            value["page_name"] = DEFAULT_PAGE_NAME
            value["session_id"] = session_id
            value["network_type"] = "WIFI"
            body = {"key": "page_d1", "value": value}
            resp = self.generic_client.post_json(
                REPORT_SINGLE_URL,
                fresh_headers(
                    identity.headers, "application/json", "application/json", None
                ),
                body,
            )
            if not 200 <= resp.status < 300:
                raise YsptpError(
                    f"page event HTTP {http_status_text(resp.status, resp.reason)}"
                )

    def cloud_registration_flow(self, identity: Identity, cloud_device_id: str) -> str:
        body = {
            "device_name": DEFAULT_DEVICE_NAME,
            "device_id": rsa_encrypt_device_id(cloud_device_id),
        }
        with self.control_request_slot("cloud_get"):
            resp = self.generic_client.post_json(
                CLOUD_GET_URL,
                fresh_headers(
                    identity.headers, "application/json", "application/json", None
                ),
                body,
            )
        _, _, value = response_json(resp)
        result = parse_result_code(value)
        if result == RESULT_OK:
            return extract_guid(value)
        if result != RESULT_NEEDS_REGISTER and result != RESULT_GET_MISSING_OR_INVALID:
            return ""
        last_result = None
        guid = ""
        for _ in range(2):
            with self.control_request_slot("cloud_register"):
                resp = self.generic_client.post_json(
                    CLOUD_REGISTER_URL,
                    fresh_headers(
                        identity.headers, "application/json", "application/json", None
                    ),
                    body,
                )
            _, _, value = response_json(resp)
            last_result = parse_result_code(value)
            guid = extract_guid(value)
            if guid or last_result != RESULT_REGISTER_RETRY_LATER:
                break
        if guid:
            return guid
        if last_result in (
            RESULT_OK,
            RESULT_REGISTERED_ELSEWHERE,
            RESULT_GET_MISSING_OR_INVALID,
        ):
            with self.control_request_slot("cloud_get_after_register"):
                resp = self.generic_client.post_json(
                    CLOUD_GET_URL,
                    fresh_headers(
                        identity.headers, "application/json", "application/json", None
                    ),
                    body,
                )
            _, _, value = response_json(resp)
            return extract_guid(value)
        return ""

    def device_info_report_flow(
        self,
        profile: DeviceProfile,
        identity: Identity,
        app_channel: str,
        version: str,
        cloud_guid: str,
    ) -> None:
        with self.control_request_slot("device_info_report"):
            value = build_report_common_value(
                profile, identity.x_uid, app_channel, version, "", current_time_ms()
            )
            sdk_int = infer_sdk_int(profile)
            system_info = infer_os_version(profile)
            if sdk_int:
                system_info = sdk_int if not system_info else f"{system_info}/{sdk_int}"
            value["version"] = version
            value["network_status"] = "WiFi"
            value["device_info"] = f"{profile.brand}-{profile.model}"
            value["manufacturer"] = profile.manufacturer
            value["cpu_info"] = ""
            value["chip_info"] = profile.hardware
            value["ram_info"] = ""
            value["memory_info"] = ""
            value["system_info"] = system_info
            value["guid"] = cloud_guid
            body = {"key": "app_device_info", "value": value}
            resp = self.generic_client.post_json(
                REPORT_SINGLE_URL,
                fresh_headers(
                    identity.headers, "application/json", "application/json", None
                ),
                body,
            )
            if not 200 <= resp.status < 300:
                raise YsptpError(
                    f"device info HTTP {http_status_text(resp.status, resp.reason)}"
                )

    def heartbeat_flow(
        self,
        profile: DeviceProfile,
        identity: Identity,
        app_channel: str,
        version: str,
        cloud_guid: str,
    ) -> str:
        with self.control_request_slot("heartbeat"):
            value = build_report_common_value(
                profile, identity.x_uid, app_channel, version, "", current_time_ms()
            )
            value["network_type"] = "WiFi"
            value["guid"] = cloud_guid
            value["other"] = ""
            body = {"key": "app_heartbeat", "value": value}
            resp = self.generic_client.post_json(
                REPORT_SINGLE_URL,
                fresh_headers(
                    identity.headers, "application/json", "application/json", None
                ),
                body,
            )
            status, _text, value = response_json(resp)
            if not 200 <= status < 300:
                raise YsptpError(f"heartbeat HTTP {status}")
            code = parse_result_code(value)
            return "" if code is None else str(code)

    def index_flow(
        self, client: HttpClient, identity: Identity, app_channel: str
    ) -> None:
        body = {"channel": app_channel, "source": "application"}
        with self.control_request_slot("index"):
            resp = client.post_json(
                INDEX_URL,
                fresh_headers(
                    identity.headers, "application/json", "application/json", None
                ),
                body,
            )
            if not 200 <= resp.status < 300:
                raise YsptpError(
                    f"index HTTP {http_status_text(resp.status, resp.reason)}"
                )

    def warmup_flow(self, client: HttpClient, identity: Identity, version: str) -> None:
        appcommon = build_vdn_appcommon(version)
        with self.control_request_slot("drm_config"):
            resp = client.post_form(
                DRM_CONFIG_URL,
                fresh_headers(
                    identity.headers, "application/x-www-form-urlencoded", None, None
                ),
                [("appcommon", appcommon)],
            )
            if not 200 <= resp.status < 300:
                raise YsptpError(
                    f"drm config HTTP {http_status_text(resp.status, resp.reason)}"
                )
        url = f"{VERSION_CONFIG_URL}?appcommon={form_urlencode_value(appcommon)}"
        with self.control_request_slot("version_config"):
            headers = fresh_headers(identity.headers, "", None, None)
            headers.pop("Content-Type", None)
            resp = client.get(url, headers)
            if not 200 <= resp.status < 300:
                raise YsptpError(
                    f"version config HTTP {http_status_text(resp.status, resp.reason)}"
                )

    def resolve_channel_once(
        self, sess: AppSession, channel: str, live_id: str, generation: int
    ) -> ChannelEntry:
        live01 = self.live_v1_01_flow(sess, live_id)
        app_secret = self.live_v1_02_flow(sess)
        vdn = self.vdn_getstream_flow(
            sess.identity, sess.version, live01.live_url, app_secret
        )
        now = now_f64()
        playback_headers = default_cctv_playback_headers(sess.profile.android_id)
        playback_headers["APPRANDOMSTR"] = vdn.app_random_str
        playback_headers["APPSIGN"] = vdn.app_sign
        return ChannelEntry(
            channel=channel,
            live_id=live_id,
            final_url=vdn.final_url,
            playback_headers=playback_headers,
            android_id=sess.profile.android_id,
            x_uid=sess.identity.x_uid,
            rate=live01.rate,
            rate_name=live01.rate_name,
            raw_live_host=url_host(live01.live_url),
            final_host=url_host(vdn.final_url),
            refreshed_at=now,
            expires_at=now + float(self.args.cache_ttl),
            generation=generation,
            last_refresh_error="",
            last_refresh_failed_at=0.0,
            session_generation=sess.generation,
        )

    def live_v1_01_flow(self, sess: AppSession, live_id: str) -> Live01Result:
        body = {
            "screenParam": sess.screen_param,
            "rate": "",
            "systemType": "ios",
            "model": sess.cast_model,
            "id": live_id,
            "userId": DEFAULT_LIVE_USER_ID,
            "clientSign": "cctvVideo",
            "deviceId": {"serial": "", "imei": "", "android_id": ""},
        }
        with self.control_request_slot("live_v1_01"):
            resp = sess.client.post_json(
                LIVE_V1_01_URL,
                fresh_headers(
                    sess.identity.headers, "application/json", "application/json", None
                ),
                body,
            )
        status, text, value = response_json(resp)
        if not 200 <= status < 300:
            raise YsptpError(f"live/v1/01 HTTP {status}: {text[:300]}")
        videos = None
        if isinstance(value, dict):
            data = value.get("data")
            if isinstance(data, dict):
                videos = data.get("videoList") or data.get("videos")
        if not isinstance(videos, list):
            raise YsptpError("live/v1/01 missing videos")
        available = [
            v
            for v in videos
            if isinstance(v, dict) and isinstance(v.get("url"), str) and v["url"]
        ]
        video = max(
            available, key=lambda v: advertised_rate(v.get("rate")), default=None
        )
        if video is None:
            raise YsptpError("live/v1/01 no usable URL")
        raw_url = video.get("url", "")
        if raw_url.startswith("http://") or raw_url.startswith("https://"):
            live_url = raw_url
        else:
            live_url = aes_gcm_decrypt_b64(raw_url, sess.session_key)
        rate = video.get("rate")
        rate_name = video.get("rateName")
        return Live01Result(
            live_url=live_url,
            rate=rate if isinstance(rate, str) else "",
            rate_name=rate_name if isinstance(rate_name, str) else "",
        )

    def live_v1_02_flow(self, sess: AppSession) -> str:
        with self.control_request_slot("live_v1_02"):
            encrypted_guid = aes_gcm_encrypt_b64("", sess.session_key)
            body = {"guid": encrypted_guid}
            resp = sess.client.post_json(
                LIVE_V1_02_URL,
                fresh_headers(
                    sess.identity.headers, "application/json", "application/json", None
                ),
                body,
            )
        status, text, value = response_json(resp)
        if not 200 <= status < 300:
            raise YsptpError(f"live/v1/02 HTTP {status}: {text[:300]}")
        encrypted = None
        if isinstance(value, dict):
            data = value.get("data")
            if isinstance(data, dict):
                for key in ("appSecret", "app_secret"):
                    v = data.get(key)
                    if isinstance(v, str):
                        encrypted = v
                        break
            if encrypted is None and isinstance(data, str):
                encrypted = data
        if encrypted is None:
            raise YsptpError("live/v1/02 missing appSecret")
        return aes_gcm_decrypt_b64(encrypted, sess.session_key)

    def vdn_getstream_flow(
        self, identity: Identity, version: str, live_url: str, app_secret: str
    ) -> VdnGetStreamResult:
        with self.control_request_slot("vdn_getstream"):
            app_sign, random_str = compute_vdn_code(app_secret, None)
            headers = fresh_headers(
                identity.headers, "application/x-www-form-urlencoded", None, None
            )
            headers["APPID"] = AK
            headers["APPSIGN"] = app_sign
            headers["APPRANDOMSTR"] = random_str
            appcommon = build_vdn_appcommon(version)
            resp = self.generic_client.post_form(
                VDN_GETSTREAM_URL,
                headers,
                [("appcommon", appcommon), ("url", live_url)],
            )
        status, text, value = response_json(resp)
        if not 200 <= status < 300:
            raise YsptpError(f"VDN HTTP {status}: {text[:300]}")
        if isinstance(value, dict):
            succeed = value.get("succeed")
            succeed_str = (
                succeed.strip('"')
                if isinstance(succeed, str)
                else json.dumps(
                    succeed, separators=(",", ":"), ensure_ascii=False
                ).strip('"')
                if succeed is not None
                else ""
            )
            if succeed_str == "1":
                url = value.get("url")
                if isinstance(url, str):
                    return VdnGetStreamResult(
                        final_url=url, app_sign=app_sign, app_random_str=random_str
                    )
        raise YsptpError(f"VDN did not return final URL: {text[:400]}")

    def send_heartbeat(self) -> None:
        if not self.control_lock.acquire(blocking=False):
            return
        try:
            while True:
                with self.state_lock:
                    sess = self.state.app_session
                    if sess is None:
                        return
                    if not self.app_session_fresh(sess):
                        sess.last_heartbeat_error = (
                            "session soft TTL reached; heartbeat paused until next "
                            "on-demand refresh"
                        )
                        need_meta = True
                    else:
                        remaining = self.app_session_ttl_remaining(sess)
                        if remaining is not None and remaining <= max(
                            0.0, float(self.args.heartbeat_ttl_guard)
                        ):
                            sess.last_heartbeat_error = (
                                "session TTL guard active; heartbeat skipped with "
                                f"{max(0.0, remaining):.3f}s remaining"
                            )
                            need_meta = True
                        else:
                            need_meta = False
                            wait = float(self.args.refresh_interval) - (
                                now_f64() - self.state.last_business_end_at
                            )
                            if wait > 0.0:
                                do_sleep = True
                            else:
                                do_sleep = False
                    if need_meta:
                        return
                if do_sleep:
                    time.sleep(wait)
                    continue
                try:
                    code = self.heartbeat_flow(
                        sess.profile,
                        sess.identity,
                        "dangbei",
                        sess.version,
                        sess.cloud_guid,
                    )
                except YsptpError as err:
                    err_text = str(err)
                    with self.state_lock:
                        if self.state.app_session is not None:
                            self.state.app_session.last_heartbeat_error = err_text
                        self.state.last_error = f"heartbeat failed: {err_text}"
                        self.state.last_error_at = now_f64()
                    raise
                with self.state_lock:
                    self.state.last_business_end_at = now_f64()
                    if self.state.app_session is not None:
                        s = self.state.app_session
                        s.last_heartbeat_at = now_f64()
                        s.heartbeat_count += 1
                        s.last_heartbeat_result = code
                        s.last_heartbeat_error = ""
                return
        finally:
            self.control_lock.release()


DEVICE_IDS = {
    "cctv1": "Live1717729995180256",
    "cctv2": "Live1718261577870260",
    "cctv3": "Live1718261955077261",
    "cctv4": "Live1718276148119264",
    "cctv5": "Live1719474204987287",
    "cctv5p": "Live1719473996025286",
    "cctv7": "Live1718276412224269",
    "cctv8": "Live1718276458899270",
    "cctv9": "Live1718276503187272",
    "cctv10": "Live1718276550002273",
    "cctv11": "Live1718276603690275",
    "cctv12": "Live1718276623932276",
    "cctv13": "Live1718276575708274",
    "cctv14": "Live1718276498748271",
    "cctv15": "Live1718276319614267",
    "cctv16": "Live1718276256572265",
    "cctv17": "Live1718276138318263",
    "cctv4k": "Live1767871224782105",
    "cctv8k": "Live1688400593818102",
    "cctv164k": "Live1704966749996185",
    "cgtn": "Live1719392219423280",
    "cgtnfr": "Live1719392670442283",
    "cgtnru": "Live1719392779653284",
    "cgtnar": "Live1719392885692285",
    "cgtnes": "Live1719392560433282",
    "cgtndoc": "Live1719392360336281",
}

CATALOG = [
    (
        "cctv1",
        "CCTV-1 综合",
        "央视",
        "2024078201",
        "600001859",
        "fhd",
        "CCTV1",
        "https://garysclub.sharewithyou.dpdns.org/logos/ysp-live-logos/cctv1.png",
        True,
    ),
    (
        "cctv2",
        "CCTV-2 财经",
        "央视",
        "2024075401",
        "600001800",
        "fhd",
        "CCTV2",
        "https://garysclub.sharewithyou.dpdns.org/logos/ysp-live-logos/cctv2.png",
        True,
    ),
    (
        "cctv3",
        "CCTV-3 综艺",
        "央视",
        "2024068501",
        "600001801",
        "fhd",
        "CCTV3",
        "https://garysclub.sharewithyou.dpdns.org/logos/ysp-live-logos/cctv3.png",
        True,
    ),
    (
        "cctv4",
        "CCTV-4 中文国际",
        "央视",
        "2029797101",
        "600001814",
        "fhd",
        "CCTV4",
        "https://garysclub.sharewithyou.dpdns.org/logos/ysp-live-logos/cctv4.png",
        True,
    ),
    (
        "cctv5",
        "CCTV-5 体育",
        "央视",
        "2024078401",
        "600001818",
        "fhd",
        "CCTV5",
        "https://garysclub.sharewithyou.dpdns.org/logos/ysp-live-logos/cctv5.png",
        True,
    ),
    (
        "cctv5p",
        "CCTV-5+ 体育赛事",
        "央视",
        "2024078001",
        "600001817",
        "fhd",
        "CCTV5+",
        "https://garysclub.sharewithyou.dpdns.org/logos/ysp-live-logos/cctv5p.png",
        True,
    ),
    (
        "cctv6",
        "CCTV-6 电影",
        "央视",
        "2013693901",
        "600108442",
        "fhd",
        "CCTV6",
        "https://garysclub.sharewithyou.dpdns.org/logos/ysp-live-logos/cctv6.png",
        True,
    ),
    (
        "cctv7",
        "CCTV-7 国防军事",
        "央视",
        "2024072001",
        "600004092",
        "fhd",
        "CCTV7",
        "https://garysclub.sharewithyou.dpdns.org/logos/ysp-live-logos/cctv7.png",
        True,
    ),
    (
        "cctv8",
        "CCTV-8 电视剧",
        "央视",
        "2029793001",
        "600001803",
        "fhd",
        "CCTV8",
        "https://garysclub.sharewithyou.dpdns.org/logos/ysp-live-logos/cctv8.png",
        True,
    ),
    (
        "cctv9",
        "CCTV-9 纪录",
        "央视",
        "2024078601",
        "600004078",
        "fhd",
        "CCTV9",
        "https://garysclub.sharewithyou.dpdns.org/logos/ysp-live-logos/cctv9.png",
        True,
    ),
    (
        "cctv10",
        "CCTV-10 科教",
        "央视",
        "2024078701",
        "600001805",
        "fhd",
        "CCTV10",
        "https://garysclub.sharewithyou.dpdns.org/logos/ysp-live-logos/cctv10.png",
        True,
    ),
    (
        "cctv11",
        "CCTV-11 戏曲",
        "央视",
        "2027248701",
        "600001806",
        "fhd",
        "CCTV11",
        "https://garysclub.sharewithyou.dpdns.org/logos/ysp-live-logos/cctv11.png",
        False,
    ),
    (
        "cctv12",
        "CCTV-12 社会与法",
        "央视",
        "2027248801",
        "600001807",
        "fhd",
        "CCTV12",
        "https://garysclub.sharewithyou.dpdns.org/logos/ysp-live-logos/cctv12.png",
        False,
    ),
    (
        "cctv13",
        "CCTV-13 新闻",
        "央视",
        "2029797201",
        "600001811",
        "fhd",
        "CCTV13",
        "https://garysclub.sharewithyou.dpdns.org/logos/ysp-live-logos/cctv13.png",
        True,
    ),
    (
        "cctv14",
        "CCTV-14 少儿",
        "央视",
        "2027248901",
        "600001809",
        "fhd",
        "CCTV14",
        "https://garysclub.sharewithyou.dpdns.org/logos/ysp-live-logos/cctv14.png",
        False,
    ),
    (
        "cctv15",
        "CCTV-15 音乐",
        "央视",
        "2027249001",
        "600001815",
        "fhd",
        "CCTV15",
        "https://garysclub.sharewithyou.dpdns.org/logos/ysp-live-logos/cctv15.png",
        False,
    ),
    (
        "cctv16",
        "CCTV-16 奥林匹克",
        "央视",
        "2027249101",
        "600098637",
        "fhd",
        "CCTV16",
        "https://garysclub.sharewithyou.dpdns.org/logos/ysp-live-logos/cctv16.png",
        False,
    ),
    (
        "cctv164k",
        "CCTV-16 4K",
        "央视",
        "2027249301",
        "600099502",
        "fhd",
        "CCTV16",
        "https://garysclub.sharewithyou.dpdns.org/logos/ysp-live-logos/cctv164k.png",
        False,
    ),
    (
        "cctv17",
        "CCTV-17 农业农村",
        "央视",
        "2027249401",
        "600001810",
        "fhd",
        "CCTV17",
        "https://garysclub.sharewithyou.dpdns.org/logos/ysp-live-logos/cctv17.png",
        False,
    ),
    (
        "cctv4k",
        "CCTV-4K 超高清",
        "央视",
        "2029810301",
        "600002264",
        "fhd",
        "CCTV4K",
        "https://garysclub.sharewithyou.dpdns.org/logos/ysp-live-logos/cctv4k.png",
        False,
    ),
    (
        "cctv8k",
        "CCTV-8K 超高清",
        "央视",
        "2026774101",
        "600156816",
        "fhd",
        "CCTV-8K",
        "https://garysclub.sharewithyou.dpdns.org/logos/ysp-live-logos/cctv8k.png",
        True,
    ),
    (
        "cgtn",
        "CGTN",
        "央视",
        "2024181701",
        "600014550",
        "fhd",
        "CGTN英语",
        "https://garysclub.sharewithyou.dpdns.org/logos/ysp-live-logos/cgtn.png",
        True,
    ),
    (
        "cgtnfr",
        "CGTN 法语",
        "央视",
        "2024181801",
        "600084704",
        "fhd",
        "CGTN法语",
        "https://garysclub.sharewithyou.dpdns.org/logos/ysp-live-logos/cgtnfr.png",
        True,
    ),
    (
        "cgtnru",
        "CGTN 俄语",
        "央视",
        "2024181901",
        "600084758",
        "fhd",
        "CGTN俄语",
        "https://garysclub.sharewithyou.dpdns.org/logos/ysp-live-logos/cgtnru.png",
        True,
    ),
    (
        "cgtnar",
        "CGTN 阿拉伯语",
        "央视",
        "2024182001",
        "600084782",
        "fhd",
        "CGTN阿语",
        "https://garysclub.sharewithyou.dpdns.org/logos/ysp-live-logos/cgtnar.png",
        True,
    ),
    (
        "cgtnes",
        "CGTN 西班牙语",
        "央视",
        "2024182101",
        "600084744",
        "fhd",
        "CGTN西语",
        "https://garysclub.sharewithyou.dpdns.org/logos/ysp-live-logos/cgtnes.png",
        True,
    ),
    (
        "cgtndoc",
        "CGTN 纪录",
        "央视",
        "2024182301",
        "600084781",
        "fhd",
        "CGTN纪录",
        "https://garysclub.sharewithyou.dpdns.org/logos/ysp-live-logos/cgtndoc.png",
        True,
    ),
    (
        "cctvfyjc",
        "CCTV 风云剧场",
        "央视",
        "2025637102",
        "600099658",
        "shd",
        "CCTV风云剧场",
        "https://garysclub.sharewithyou.dpdns.org/logos/ysp-live-logos/cctvfyjc.png",
        False,
    ),
    (
        "cctvdyjc",
        "CCTV 第一剧场",
        "央视",
        "2026874202",
        "600099655",
        "shd",
        "CCTV第一剧场",
        "https://garysclub.sharewithyou.dpdns.org/logos/ysp-live-logos/cctvdyjc.png",
        False,
    ),
    (
        "cctvhjjc",
        "CCTV 怀旧剧场",
        "央视",
        "2026874302",
        "600099620",
        "shd",
        "CCTV怀旧剧场",
        "https://garysclub.sharewithyou.dpdns.org/logos/ysp-live-logos/cctvhjjc.png",
        False,
    ),
    (
        "bjws",
        "北京卫视",
        "卫视",
        "2024052703",
        "600002309",
        "fhd",
        "北京卫视",
        "https://garysclub.sharewithyou.dpdns.org/logos/ysp-live-logos/bjws.png",
        True,
    ),
    (
        "jsws",
        "江苏卫视",
        "卫视",
        "2024171103",
        "600002521",
        "fhd",
        "江苏卫视",
        "https://garysclub.sharewithyou.dpdns.org/logos/ysp-live-logos/jsws.png",
        True,
    ),
    (
        "dfws",
        "东方卫视",
        "卫视",
        "2024054503",
        "600002483",
        "fhd",
        "东方卫视",
        "https://garysclub.sharewithyou.dpdns.org/logos/ysp-live-logos/dfws.png",
        True,
    ),
    (
        "zjws",
        "浙江卫视",
        "卫视",
        "2024054703",
        "600002520",
        "fhd",
        "浙江卫视",
        "https://garysclub.sharewithyou.dpdns.org/logos/ysp-live-logos/zjws.png",
        True,
    ),
    (
        "hnws",
        "湖南卫视",
        "卫视",
        "2024054803",
        "600002475",
        "fhd",
        "湖南卫视",
        "https://garysclub.sharewithyou.dpdns.org/logos/ysp-live-logos/hnws.png",
        True,
    ),
    (
        "hbws",
        "湖北卫视",
        "卫视",
        "2024171203",
        "600002508",
        "fhd",
        "湖北卫视",
        "https://garysclub.sharewithyou.dpdns.org/logos/ysp-live-logos/hbws.png",
        True,
    ),
    (
        "gdws",
        "广东卫视",
        "卫视",
        "2024060903",
        "600002485",
        "fhd",
        "广东卫视",
        "https://garysclub.sharewithyou.dpdns.org/logos/ysp-live-logos/gdws.png",
        True,
    ),
    (
        "gxws",
        "广西卫视",
        "卫视",
        "2024060703",
        "600002509",
        "fhd",
        "广西卫视",
        "https://garysclub.sharewithyou.dpdns.org/logos/ysp-live-logos/gxws.png",
        True,
    ),
    (
        "hljws",
        "黑龙江卫视",
        "卫视",
        "2029797003",
        "600002498",
        "fhd",
        "黑龙江卫视",
        "https://garysclub.sharewithyou.dpdns.org/logos/ysp-live-logos/hljws.png",
        True,
    ),
    (
        "hainanws",
        "海南卫视",
        "卫视",
        "2024055603",
        "600002506",
        "fhd",
        "海南卫视",
        "https://garysclub.sharewithyou.dpdns.org/logos/ysp-live-logos/hainanws.png",
        True,
    ),
    (
        "cqws",
        "重庆卫视",
        "卫视",
        "2024061103",
        "600002531",
        "fhd",
        "重庆卫视",
        "https://garysclub.sharewithyou.dpdns.org/logos/ysp-live-logos/cqws.png",
        True,
    ),
    (
        "szws",
        "深圳卫视",
        "卫视",
        "2024061303",
        "600002481",
        "fhd",
        "深圳卫视",
        "https://garysclub.sharewithyou.dpdns.org/logos/ysp-live-logos/szws.png",
        True,
    ),
    (
        "scws",
        "四川卫视",
        "卫视",
        "2024061403",
        "600002516",
        "fhd",
        "四川卫视",
        "https://garysclub.sharewithyou.dpdns.org/logos/ysp-live-logos/scws.png",
        True,
    ),
    (
        "henanws",
        "河南卫视",
        "卫视",
        "2029797303",
        "600002525",
        "fhd",
        "河南卫视",
        "https://garysclub.sharewithyou.dpdns.org/logos/ysp-live-logos/henanws.png",
        True,
    ),
    (
        "dnws",
        "东南卫视",
        "卫视",
        "2024061503",
        "600002484",
        "fhd",
        "东南卫视",
        "https://garysclub.sharewithyou.dpdns.org/logos/ysp-live-logos/dnws.png",
        True,
    ),
    (
        "gzws",
        "贵州卫视",
        "卫视",
        "2024061603",
        "600002490",
        "fhd",
        "贵州卫视",
        "https://garysclub.sharewithyou.dpdns.org/logos/ysp-live-logos/gzws.png",
        True,
    ),
    (
        "jxws",
        "江西卫视",
        "卫视",
        "2024061703",
        "600002503",
        "fhd",
        "江西卫视",
        "https://garysclub.sharewithyou.dpdns.org/logos/ysp-live-logos/jxws.png",
        True,
    ),
    (
        "lnws",
        "辽宁卫视",
        "卫视",
        "2024171303",
        "600002505",
        "fhd",
        "辽宁卫视",
        "https://garysclub.sharewithyou.dpdns.org/logos/ysp-live-logos/lnws.png",
        True,
    ),
    (
        "ahws",
        "安徽卫视",
        "卫视",
        "2024171403",
        "600002532",
        "fhd",
        "安徽卫视",
        "https://garysclub.sharewithyou.dpdns.org/logos/ysp-live-logos/ahws.png",
        True,
    ),
    (
        "hebws",
        "河北卫视",
        "卫视",
        "2024171503",
        "600002493",
        "fhd",
        "河北卫视",
        "https://garysclub.sharewithyou.dpdns.org/logos/ysp-live-logos/hebws.png",
        True,
    ),
    (
        "sdws",
        "山东卫视",
        "卫视",
        "2029787903",
        "600002513",
        "fhd",
        "山东卫视",
        "https://garysclub.sharewithyou.dpdns.org/logos/ysp-live-logos/sdws.png",
        True,
    ),
    (
        "tjws",
        "天津卫视",
        "卫视",
        "2019927003",
        "600152137",
        "fhd",
        "天津卫视",
        "https://garysclub.sharewithyou.dpdns.org/logos/ysp-live-logos/tjws.png",
        True,
    ),
    (
        "jlws",
        "吉林卫视",
        "卫视",
        "2025561503",
        "600190405",
        "fhd",
        "吉林卫视",
        "https://garysclub.sharewithyou.dpdns.org/logos/ysp-live-logos/jlws.png",
        True,
    ),
    (
        "saxws",
        "陕西卫视",
        "卫视",
        "2029795103",
        "600190400",
        "fhd",
        "陕西卫视",
        "https://garysclub.sharewithyou.dpdns.org/logos/ysp-live-logos/saxws.png",
        True,
    ),
    (
        "nxws",
        "宁夏卫视",
        "卫视",
        "2025608503",
        "600190737",
        "fhd",
        "宁夏卫视",
        "https://garysclub.sharewithyou.dpdns.org/logos/ysp-live-logos/nxws.png",
        True,
    ),
    (
        "nmgws",
        "内蒙古卫视",
        "卫视",
        "2025561203",
        "600190401",
        "fhd",
        "内蒙古卫视",
        "https://garysclub.sharewithyou.dpdns.org/logos/ysp-live-logos/nmgws.png",
        True,
    ),
    (
        "ynws",
        "云南卫视",
        "卫视",
        "2025561303",
        "600190402",
        "fhd",
        "云南卫视",
        "https://garysclub.sharewithyou.dpdns.org/logos/ysp-live-logos/ynws.png",
        True,
    ),
    (
        "shanxiws",
        "山西卫视",
        "卫视",
        "2025560803",
        "600190407",
        "fhd",
        "山西卫视",
        "https://garysclub.sharewithyou.dpdns.org/logos/ysp-live-logos/shanxiws.png",
        True,
    ),
    (
        "gsws",
        "甘肃卫视",
        "卫视",
        "2025561703",
        "600190408",
        "fhd",
        "甘肃卫视",
        "https://garysclub.sharewithyou.dpdns.org/logos/ysp-live-logos/gsws.png",
        True,
    ),
    (
        "qhws",
        "青海卫视",
        "卫视",
        "2025559103",
        "600190406",
        "fhd",
        "青海卫视",
        "https://garysclub.sharewithyou.dpdns.org/logos/ysp-live-logos/qhws.png",
        True,
    ),
    (
        "xizangws",
        "西藏卫视",
        "卫视",
        "2025558003",
        "600190403",
        "fhd",
        "西藏卫视",
        "https://garysclub.sharewithyou.dpdns.org/logos/ysp-live-logos/xizangws.png",
        True,
    ),
    (
        "xjws",
        "新疆卫视",
        "卫视",
        "2019927403",
        "600152138",
        "fhd",
        "新疆卫视",
        "https://garysclub.sharewithyou.dpdns.org/logos/ysp-live-logos/xjws.png",
        True,
    ),
    (
        "cetv1",
        "CETV-1",
        "卫视",
        "2022823801",
        "600171827",
        "fhd",
        "CETV1",
        "https://garysclub.sharewithyou.dpdns.org/logos/ysp-live-logos/cetv1.png",
        True,
    ),
    (
        "guoxue",
        "国学频道",
        "卫视",
        "2029360403",
        "600213139",
        "fhd",
        "国学",
        "https://garysclub.sharewithyou.dpdns.org/logos/ysp-live-logos/guoxue.png",
        True,
    ),
]
ALIASES = {
    "anhuiws": "ahws",
    "beijingws": "bjws",
    "cctv16hd": "cctv16",
    "cctv5plus": "cctv5p",
    "cctvdiyijuchang": "cctvdyjc",
    "cctvfengyunjuchang": "cctvfyjc",
    "cctvhuaijiujuchang": "cctvhjjc",
    "cgtnalaboyu": "cgtnar",
    "cgtneyu": "cgtnru",
    "cgtnfayu": "cgtnfr",
    "cgtnwaiyujilu": "cgtndoc",
    "cgtnxibanyayu": "cgtnes",
    "chongqingws": "cqws",
    "dongfangws": "dfws",
    "fujiandongnanws": "dnws",
    "guangdongws": "gdws",
    "guangxiws": "gxws",
    "guizhouws": "gzws",
    "hebeiws": "hebws",
    "heilongjiangws": "hljws",
    "hubeiws": "hbws",
    "hunanws": "hnws",
    "jiangsuws": "jsws",
    "jiangxiws": "jxws",
    "jilinws": "jlws",
    "liaoningws": "lnws",
    "neimengguws": "nmgws",
    "ningxiaws": "nxws",
    "qinghaiws": "qhws",
    "shandongws": "sdws",
    "shannxiws": "saxws",
    "shenzhenws": "szws",
    "sichuanws": "scws",
    "tianjinws": "tjws",
    "xinjiangws": "xjws",
    "yunnanws": "ynws",
    "zhejiangws": "zjws",
}


class W:
    def __init__(self):
        self.b = bytearray()

    def head(self, typ, tag):
        if tag < 15:
            self.b.append((tag & 15) << 4 | typ & 15)
        else:
            self.b.append(240 | typ & 15)
            self.b.append(tag)

    def byte(self, v, tag):
        v = int(v)
        if v == 0:
            self.head(12, tag)
        else:
            self.head(0, tag)
            self.b += struct.pack(">b", v)

    def short(self, v, tag):
        v = int(v)
        if -128 <= v <= 127:
            self.byte(v, tag)
        else:
            self.head(1, tag)
            self.b += struct.pack(">h", v)

    def int(self, v, tag):
        v = int(v)
        if -32768 <= v <= 32767:
            self.short(v, tag)
        else:
            self.head(2, tag)
            self.b += struct.pack(">i", v)

    def long(self, v, tag):
        v = int(v)
        if -2147483648 <= v <= 2147483647:
            self.int(v, tag)
        else:
            self.head(3, tag)
            self.b += struct.pack(">q", v)

    def float(self, v, tag):
        self.head(4, tag)
        self.b += struct.pack(">f", float(v))

    def double(self, v, tag):
        self.head(5, tag)
        self.b += struct.pack(">d", float(v))

    def string(self, s, tag):
        if s is None:
            return
        data = str(s).encode("utf-8")
        if len(data) > 255:
            self.head(7, tag)
            self.b += struct.pack(">i", len(data))
            self.b += data
        else:
            self.head(6, tag)
            self.b.append(len(data))
            self.b += data

    def bytes(self, data, tag):
        data = bytes(data)
        self.head(13, tag)
        self.head(0, 0)
        self.int(len(data), 0)
        self.b += data

    def struct(self, fn, tag):
        self.head(10, tag)
        fn(self)
        self.head(11, 0)

    def list(self, items, tag, wf):
        self.head(9, tag)
        self.int(len(items), 0)
        if wf is not None:
            for item in items:
                wf(self, item)

    def out(self):
        return bytes(self.b)


class R:
    def __init__(self, data):
        self.d = memoryview(data)
        self.p = 0

    def rem(self):
        return len(self.d) - self.p

    def get(self, n):
        if self.p + n > len(self.d):
            raise EOFError
        b = self.d[self.p : self.p + n].tobytes()
        self.p += n
        return b

    def u8(self):
        return self.get(1)[0]

    def head(self):
        b = self.u8()
        typ = b & 15
        tag = (b & 240) >> 4
        if tag == 15:
            tag = self.u8()
        return (typ, tag)

    def value(self, typ):
        if typ == 0:
            return struct.unpack(">b", self.get(1))[0]
        if typ == 1:
            return struct.unpack(">h", self.get(2))[0]
        if typ == 2:
            return struct.unpack(">i", self.get(4))[0]
        if typ == 3:
            return struct.unpack(">q", self.get(8))[0]
        if typ == 4:
            return struct.unpack(">f", self.get(4))[0]
        if typ == 5:
            return struct.unpack(">d", self.get(8))[0]
        if typ == 6:
            n = self.u8()
            return self.get(n).decode("utf-8", "replace")
        if typ == 7:
            n = struct.unpack(">i", self.get(4))[0]
            return self.get(n).decode("utf-8", "replace")
        if typ == 8:
            n = self._int()
            return {self._fv(): self._fv() for _ in range(n)}
        if typ == 9:
            n = self._int()
            return [self._fv() for _ in range(n)]
        if typ == 10:
            return self.struct()
        if typ == 11:
            return None
        if typ == 12:
            return 0
        if typ == 13:
            t, _ = self.head()
            n = self._int()
            return self.get(n)
        raise ValueError("type %d" % typ)

    def _fv(self):
        t, _ = self.head()
        return self.value(t)

    def _int(self):
        t, _ = self.head()
        return int(self.value(t))

    def struct(self):
        m = {}
        while self.rem() > 0:
            t, tag = self.head()
            if t == 11:
                break
            m[tag] = self.value(t)
        return m


VER_NAME, VER_CODE = ("3.2.7.26212", "302070")
APP_ID, QMF_APP_ID, QMF_PLATFORM, BIZ_ID = ("1200013", 10012, 1, 0)
CHAN_ID = "10070"
GUID = "".join((random.choice("0123456789abcdef") for _ in range(32)))


def _qua(w):
    w.string(VER_NAME, 0)
    w.string(VER_CODE, 1)
    w.int(1080, 2)
    w.int(2400, 3)
    w.int(3, 4)
    w.string("12", 5)
    w.int(1, 6)
    w.int(1, 7)
    w.int(420, 8)
    w.string(CHAN_ID, 9)
    for i in range(10, 15):
        w.string("", i)
    w.struct(lambda ww: (ww.int(0, 0), ww.byte(0, 1), ww.string("", 2)), 15)
    w.string("", 16)
    w.string("", 17)
    w.string("", 18)
    w.struct(
        lambda ww: (ww.int(0, 0), ww.float(0, 1), ww.float(0, 2), ww.double(0, 3)), 19
    )
    w.string(GUID[:16], 20)
    w.string("Pixel 6", 21)
    w.int(1, 22)
    for i in range(23, 27):
        w.int(0, i)
    w.string("", 27)
    w.string("", 28)
    w.string(GUID, 29)


def _head(w, cmd, reqid):
    w.int(reqid, 0)
    w.int(cmd, 1)
    w.struct(lambda ww: _qua(ww), 2)
    w.string(APP_ID, 3)
    w.string(GUID, 4)
    w.list([], 5, None)
    w.struct(lambda ww: None, 6)
    w.list([], 7, None)
    w.int(0, 8)
    w.int(0, 9)
    w.int(0, 10)


def _wrap(cmd, body, reqid):
    w = W()
    w.struct(lambda ww: _head(ww, cmd, reqid), 0)
    w.bytes(body, 1)
    reqcmd = w.out()
    inner = (
        bytearray([38])
        + struct.pack(">i", len(reqcmd) + 17)
        + bytes([1])
        + b"\x00" * 10
        + reqcmd
        + bytes([40])
    )
    comp = gzip.compress(bytes(inner))
    out = (
        bytearray([19])
        + struct.pack(">i", 0)
        + struct.pack(">H", 2)
        + struct.pack(">H", 65281)
    )
    out += struct.pack(">H", cmd) + struct.pack(">H", 0) + struct.pack(">q", reqid)
    out += (
        struct.pack(">i", 531)
        + struct.pack(">i", QMF_APP_ID)
        + struct.pack(">q", BIZ_ID)
    )
    g = GUID.encode()[:32]
    out += g + b"\x00" * (32 - len(g))
    out += (
        struct.pack(">b", QMF_PLATFORM) + struct.pack(">i", int(VER_CODE)) + b"\x00" * 6
    )
    out += bytes([0]) + struct.pack(">H", 0) + struct.pack(">H", 0)
    out += struct.pack(">i", len(inner)) + comp + bytes([3])
    struct.pack_into(">i", out, 1, len(out))
    return bytes(out)


def _unwrap(data):
    if data[:1] != b"\x13" or len(data) < 90:
        return None
    flags = struct.unpack(">i", data[21:25])[0]
    payload = data[89:-1]
    if flags & 2:
        payload = gzip.decompress(payload)
    if payload[:1] != b"&" or payload[-1:] != b"(":
        return None
    rc = R(payload[16:-1]).struct()
    return rc.get(1) or b""


class DeadHostError(RuntimeError):
    pass


def jce_timeshift_url(pid, sid, start, end, stream="fhd"):
    w = W()
    w.string(pid, 0)
    w.string(sid, 1)
    w.long(start, 2)
    w.long(end, 3)
    w.string(stream, 4)
    body = w.out()
    CMD = 25312
    reqid = int(time.time() * 1000) & 2147483647
    packet = _wrap(CMD, body, reqid)
    req = urllib.request.Request("https://jacc.ysp.cctv.cn", data=packet, method="POST")
    req.add_header("Content-Type", "application/octet-stream")
    with urllib.request.urlopen(req, timeout=15) as resp:
        raw = resp.read()
    resp_body = _unwrap(raw)
    if not resp_body:
        raise RuntimeError("bad response")
    m = R(resp_body).struct()
    err = m.get(0, 0)
    if err != 0:
        raise RuntimeError(m.get(1, "errCode=%s" % err))
    url = m.get(2, "")
    if not url:
        raise RuntimeError("empty m3u8")
    if "liverecord.video.cloud.cctv.com" in url:
        raise DeadHostError("dead cdn host")
    return url


_CK_PLATFORM = 4330403
_CK_APPVER = "V8.22.1035.3031"
_CK_TEA = bytes.fromhex("59b2f7cf725ef43c34fdd7c123411ed3")
_CK_GTEA = bytes.fromhex("110DBEC10C23E7D2E56A1CAD6914EF1B")
_CK_XOR = bytes(
    [132, 46, 237, 8, 240, 102, 230, 234, 72, 180, 202, 169, 145, 237, 111, 243]
)
_CK_GXOR = bytes([179, 201, 83, 160, 105, 19, 173, 77])


def _u32(v):
    return v & 4294967295


def _tea_blk(blk, key):
    y, z = struct.unpack(">2I", blk)
    k = struct.unpack(">4I", key)
    s = 0
    for _ in range(16):
        s = _u32(s + 2654435769)
        y = _u32(
            y + _u32(_u32(_u32(z << 4) + k[0]) ^ _u32(z + s) ^ _u32((z >> 5) + k[1]))
        )
        z = _u32(
            z + _u32(_u32(_u32(y << 4) + k[2]) ^ _u32(y + s) ^ _u32((y >> 5) + k[3]))
        )
    return struct.pack(">2I", y, z)


def _cksum(buf):
    v = 0
    for b in buf:
        v = 131 * v + b & 2147483647
    return v


def _tea_pkt(data, key):
    pad = (8 - (len(data) + 10) % 8) % 8
    plain = (
        bytes([os.urandom(1)[0] & 248 | pad])
        + os.urandom(pad)
        + os.urandom(2)
        + data
        + bytes(7)
    )
    out, pp, pc = (b"", bytes(8), bytes(8))
    for off in range(0, len(plain), 8):
        mixed = bytes((a ^ b for a, b in zip(plain[off : off + 8], pc)))
        enc = _tea_blk(mixed, key)
        cipher = bytes((a ^ b for a, b in zip(enc, pp)))
        out += cipher
        pp, pc = (mixed, cipher)
    return out


def _lp(s):
    d = s.encode() if isinstance(s, str) else s
    return struct.pack(">H", len(d)) + d


def _ck_guard(ts, guid):

    def tail(v):
        t = str(v)
        return t[-5:] if len(t) >= 5 else ""

    body = (
        struct.pack(">I", ts)
        + _lp(tail(guid))
        + _lp(tail("null"))
        + _lp(tail("null"))
        + _lp("-1")
    )
    plain = _lp(body)
    enc = _tea_pkt(plain, _CK_GTEA) + struct.pack(">I", _cksum(plain))
    enc = bytes((a ^ _CK_GXOR[i & 7] for i, a in enumerate(enc)))
    return enc.hex().upper()


def _ckey(channel_id):
    ts = int(time.time())
    guid = os.urandom(16).hex()
    guard = _ck_guard(ts, guid)
    uid = os.urandom(4).hex().upper()
    body = (
        bytes.fromhex("0000004200000004000004d2")
        + struct.pack(">I", _CK_PLATFORM)
        + struct.pack(">I", 0)
        + struct.pack(">I", ts)
        + _lp("dcgh")
        + _lp("_zj1A5Gh6QYcxWjIUGos2w==")
        + _lp(_CK_APPVER)
        + _lp(str(channel_id))
        + _lp(guid)
        + struct.pack(">I", 1)
        + struct.pack(">I", 1)
        + _lp(uid)
        + _lp("nil")
        + _lp("57eab0c4-2c58-44c6-8ae9-dd2757525dc5")
        + _lp("nil")
        + _lp("v0.1.000")
        + _lp("com.cctv.yangshipin.app.iphone")
        + _lp(str(_CK_PLATFORM))
        + _lp("ex_json_bus")
        + _lp("ex_json_vs")
        + _lp(guard)
    )
    pkt = bytearray(struct.pack(">H", len(body)) + body)
    pkt[18:22] = struct.pack(">I", _cksum(bytes(pkt)))
    pkt = bytes(pkt)
    enc = _tea_pkt(pkt, _CK_TEA) + struct.pack(">I", _cksum(pkt))
    enc = bytes((a ^ _CK_XOR[i & 15] for i, a in enumerate(enc)))
    b64 = base64.b64encode(enc).decode().replace("+", "_").replace("/", "-").rstrip("=")
    return {
        "cKey": "--01" + b64,
        "guid": guid,
        "ts": ts,
        "flowId": "%s_%d" % (uuid.uuid4().hex.upper(), _CK_PLATFORM),
    }


_BK_H264 = base64.b64encode(b"H(30:1080,60:1080|30:1080,60:1080)").decode()


def bk_playurls(channel_id, live_pid, defn="fhd"):
    t = _ckey(channel_id)
    q = urllib.parse.urlencode(
        {
            "atime": "120",
            "livepid": live_pid,
            "cnlid": channel_id,
            "appVer": _CK_APPVER,
            "app_version": "300090",
            "caplv": "1",
            "cmd": "2",
            "defn": defn,
            "device": "iPhone",
            "encryptVer": "4.2",
            "getpreviewinfo": "0",
            "hevclv": "0",
            "lang": "zh-Hans_CN",
            "livequeue": "0",
            "logintype": "1",
            "nettype": "1",
            "newnettype": "1",
            "newplatform": str(_CK_PLATFORM),
            "platform": str(_CK_PLATFORM),
            "sdtfrom": "v3021",
            "spacode": "23",
            "spaudio": "1",
            "spdemuxer": "6",
            "spdrm": "2",
            "spdynamicrange": "1",
            "spflv": "1",
            "spflvaudio": "1",
            "sphdrfps": "60",
            "sphttps": "1",
            "spvcode": _BK_H264,
            "spvideo": "4",
            "stream": "1",
            "system": "1",
            "sysver": "ios18.2.1",
            "uhd_flag": "0",
            "cKey": t["cKey"],
            "guid": t["guid"],
            "fntick": str(t["ts"]),
            "flowid": t["flowId"],
            "playbacktime": "0",
        }
    )
    req = urllib.request.Request(
        "https://bkliveinfo.ysp.cctv.cn/?" + q,
        headers={"User-Agent": "qqlive", "Accept": "application/json"},
    )
    with urllib.request.urlopen(req, timeout=5) as r:
        p = json.loads(r.read().decode())
    if not isinstance(p, dict):
        raise ValueError("BK 响应格式无效")
    if str(p.get("iretcode", -1)) != "0":
        raise RuntimeError("iretcode=%s %s" % (p.get("iretcode"), p.get("errinfo", "")))
    urls = []
    if p.get("playurl"):
        urls.append(p["playurl"])
    bu = p.get("backurl_list") or p.get("backurlList") or p.get("backurl")
    if isinstance(bu, list):
        for it in bu:
            if isinstance(it, str):
                urls.append(it)
            elif isinstance(it, dict):
                urls.append(it.get("url") or it.get("playurl"))
    elif isinstance(bu, str):
        urls += [x for x in re.split("[;,]", bu) if x.strip()]
    headers = {"Referer": "https://live.cctv.cn/", "User-Agent": "qqlive"}
    hints = p.get("http_header")
    for key, value in (hints if isinstance(hints, dict) else {}).items():
        if (
            key.lower() in ("uid", "user-agent")
            and isinstance(value, str)
            and value.isascii()
            and value.isprintable()
        ):
            headers[key] = value
    return (list(dict.fromkeys(u for u in urls if upstream_url(u))), headers)


import struct
from collections import OrderedDict
from email.utils import parsedate_to_datetime

MPEGURL = "application/vnd.apple.mpegurl"
CDN_SUFFIXES = (
    "cctv.cn",
    "cctv.com",
    "cctvpic.com",
    "citvc.com",
    "yangshipin.cn",
    "cntv.cn",
    "cntv.com",
    "myqcloud.com",
    "qqlive.com",
    "gtimg.cn",
    "smtcdns.net",
    "smtcdns.com",
    "tcdnlive.com",
    "alicdn.com",
    "alikunlun.com",
    "wscdns.com",
    "chinanetcenter.com",
    "bdydns.com",
    "ksyungslb.com",
    "ks-cdn.com",
)
WEB = ""
LIMIT = 32 << 20
ROWS = {row[0]: row for row in CATALOG}
device_resolver = None


def upstream_url(url):
    if not isinstance(url, str):
        return False
    parts = urlsplit(url)
    return (
        parts.scheme in ("https", "http")
        and not parts.username
        and not parts.password
        and (
            any(
                parts.hostname == h or (parts.hostname or "").endswith("." + h)
                for h in CDN_SUFFIXES
            )
            or bool(WEB and parts[:2] == urlsplit(WEB)[:2])
        )
    )


class MediaError(Exception):
    def __init__(self, stage, code=502, delay=0):
        super().__init__(stage)
        self.code = code
        self.delay = delay


class Redirects(urllib.request.HTTPRedirectHandler):
    def redirect_request(self, req, fp, code, msg, headers, newurl):
        if not upstream_url(newurl) or (
            WEB
            and (
                (urlsplit(newurl)[:2] == urlsplit(WEB)[:2])
                != (urlsplit(req.full_url)[:2] == urlsplit(WEB)[:2])
            )
        ):
            raise MediaError("播放源重定向不可用")
        return super().redirect_request(req, fp, code, msg, headers, newurl)


opener = urllib.request.build_opener(Redirects())


def delay_from(headers):
    value = headers.get("Retry-After", "")
    try:
        return (
            max(0, int(value))
            if value.isdigit()
            else max(
                0, math.ceil(parsedate_to_datetime(value).timestamp() - time.time())
            )
        )
    except (ValueError, TypeError, OverflowError):
        return 0


local_opener = urllib.request.build_opener(urllib.request.ProxyHandler({}), Redirects())


def open_resource(url, headers, byte_range=None, timeout=10):
    if not upstream_url(url):
        raise MediaError("媒体地址不可用")
    request = urllib.request.Request(url)
    for key, value in headers.items():
        request.add_unredirected_header(key, value)
    if byte_range:
        request.add_header("Range", byte_range)
    client = local_opener if WEB and urlsplit(url)[:2] == urlsplit(WEB)[:2] else opener
    try:
        try:
            return client.open(request, timeout=timeout)
        except urllib.error.HTTPError as exc:
            if (
                exc.code != 403
                or exc.geturl() != url
                or exc.headers.get("Content-Length") != "0"
                or "WWW-Authenticate" in exc.headers
                or delay_from(exc.headers) > 6
            ):
                raise
            exc.close()
        time.sleep(6)
        return client.open(request, timeout=timeout)
    except urllib.error.HTTPError as exc:
        with exc:
            raise MediaError(
                f"媒体 HTTP {exc.code}", exc.code, delay_from(exc.headers)
            ) from None


def fetch(url, headers, limit, timeout=10):
    with open_resource(url, headers, timeout=timeout) as response:
        data = response.read(limit + 1)
        if not data or len(data) > limit:
            raise MediaError("清单过大或为空")
        return data, response.geturl(), response.status, dict(response.headers.items())


class MediaStore:
    def __init__(self, capacity):
        self.capacity = capacity
        self.lock = threading.Lock()
        self.refs = OrderedDict()
        self.bodies = OrderedDict()
        self.size = 0

    def register(self, channel, url, headers, ttl=300, high=False):
        if not upstream_url(url):
            raise MediaError("媒体清单包含不可用地址")
        key = hashlib.sha256(
            json.dumps([channel, url, headers], sort_keys=True).encode()
        ).hexdigest()
        with self.lock:
            previous = self.refs.get(key)
            expires = max(time.monotonic() + ttl, previous[2] if previous else 0)
            self.refs[key] = (url, dict(headers), expires, channel, high)
            self.refs.move_to_end(key)
            if len(self.refs) > 8192:
                self.refs.popitem(last=False)
        suffix = Path(urlsplit(url).path).suffix.lower()
        if suffix not in (".ts", ".aac", ".m4s", ".mp4", ".vtt", ".key"):
            suffix = ".ts"
        return "/media/" + key + suffix

    def lookup(self, key):
        key = key.partition(".")[0]
        with self.lock:
            ref = self.refs.get(key)
            if not ref or time.monotonic() >= ref[2]:
                raise MediaError("分片已过期", 410)
            cached = self.bodies.get(key)
            if cached:
                self.bodies.move_to_end(key)
            return ref, cached

    def remember(self, key, value):
        with self.lock:
            old = self.bodies.pop(key, None)
            if old:
                self.size -= len(old[0])
            self.bodies[key] = value
            self.size += len(value[0])
            while self.size > self.capacity:
                self.size -= len(self.bodies.popitem(last=False)[1][0])

    def probe(self, path):
        key = path.rsplit("/", 1)[-1]
        ref, cached = self.lookup(key)
        if cached:
            return cached[0][:1024]
        with open_resource(ref[0], ref[1], "bytes=0-65535") as response:
            return response.read(1024)

    def prime(self, path):
        key = path.rsplit("/", 1)[-1]
        with self.payload(key) as (_, headers, chunks):
            first = next(iter(chunks), b"")
            if len(first) < 188 or first.lstrip().startswith((b"<", b"#EXTM3U")):
                raise MediaError("高码率分片无效")
            if isinstance(chunks, tuple):
                return
            # A normal GET also checks delivery when the CDN treats Range differently.
            # Finishing a bounded response lets the first player reuse the exact segment.
            length = int(headers.get("Content-Length", 0))
            if 0 < length <= min(self.capacity, 2 << 20):
                for _ in chunks:
                    pass

    @contextlib.contextmanager
    def payload(self, key, byte_range=None):
        key = key.partition(".")[0]
        ref, cached = self.lookup(key)
        if cached:
            data, _, meta = cached
            if not byte_range:
                yield 200, meta, (data,)
                return
            selection = re.fullmatch(r"bytes=(\d+)-(\d*)", byte_range)
            if selection:
                start = int(selection[1])
                end = (
                    min(len(data) - 1, int(selection[2]))
                    if selection[2]
                    else len(data) - 1
                )
                if end < start:
                    raise MediaError("分片范围无效", 416)
                yield (
                    206,
                    dict(
                        meta,
                        **{
                            "Content-Length": str(end - start + 1),
                            "Content-Range": f"bytes {start}-{end}/{len(data)}",
                        },
                    ),
                    (data[start : end + 1],),
                )
                return
        with open_resource(
            ref[0], ref[1], byte_range, timeout=30 if ref[4] else 10
        ) as resp:
            meta = {
                k.title(): v
                for k, v in resp.headers.items()
                if k.lower()
                in ("content-type", "content-length", "accept-ranges", "content-range")
            }
            length = int(meta["Content-Length"]) if "Content-Length" in meta else None

            def chunks():
                buffer = bytearray()
                maximum = min(LIMIT, self.capacity)
                keep = resp.status == 200 and (length is None or length <= maximum)
                total = 0
                while True:
                    part = resp.read1(128 << 10)
                    if not part:
                        break
                    total += len(part)
                    if keep and total <= maximum:
                        buffer.extend(part)
                    elif keep:
                        keep = False
                        buffer.clear()
                    yield part
                if length is not None and total != length:
                    raise http.client.IncompleteRead(b"", length - total)
                if keep and total:
                    self.remember(
                        key,
                        (
                            bytes(buffer),
                            200,
                            dict(meta, **{"Content-Length": str(total)}),
                        ),
                    )

            yield resp.status, meta, chunks()

    def read(self, key, byte_range=None):
        with self.payload(key, byte_range) as (code, headers, chunks):
            return b"".join(chunks), code, headers


@dataclasses.dataclass
class Manifest:
    text: str
    refs: list
    first: int
    blocks: list
    globals: list
    simple: bool


def variant_quality(tag):
    resolution = re.search(r"(?:[:,])RESOLUTION=(\d+)x(\d+)", tag, re.I)
    bandwidth = re.search(r"(?:[:,])BANDWIDTH=(\d+)", tag)
    return (
        int(resolution[1]) * int(resolution[2]) if resolution else 0,
        int(bandwidth[1]) if bandwidth else 0,
    )


def manifest(
    channel, url, headers, store, live_record=False, ttl=300, prefer_high=False
):
    origin = urlsplit(url)[:2]

    def scoped(target):
        return headers if urlsplit(target)[:2] == origin else {}

    for _ in range(4):
        body, final, _, _headers = fetch(
            url, scoped(url), 2 << 20, 30 if prefer_high else 10
        )
        lines = [s.strip() for s in body.decode("utf-8-sig").splitlines() if s.strip()]
        if live_record:
            lines = [
                s
                for s in lines
                if not s.startswith(("#EXT-X-ENDLIST", "#EXT-X-PLAYLIST-TYPE:"))
            ]
        if not lines or lines[0] != "#EXTM3U":
            raise MediaError("播放源未返回 HLS 清单")
        variants = [
            (tag, lines[i + 1])
            for i, tag in enumerate(lines[:-1])
            if tag.startswith("#EXT-X-STREAM-INF:") and not lines[i + 1].startswith("#")
        ]
        if not variants:
            break
        selected = (
            max(variants, key=lambda v: variant_quality(v[0]))
            if prefer_high
            else variants[0]
        )
        child = selected[1]
        if not child:
            raise MediaError("主清单缺少媒体地址")
        url = urljoin(final, child)
    else:
        raise MediaError("主清单嵌套过多")
    refs, blocks, globals_, pending, rendered = [], [], [], [], []
    first = None
    simple = True

    def local(uri):
        target = urljoin(final, uri)
        return store.register(channel, target, scoped(target), ttl, high=prefer_high)

    for line in lines:
        if line.startswith("#EXT-X-MEDIA-SEQUENCE:"):
            first = int(line.split(":", 1)[1])
        elif (
            line.startswith(
                (
                    "#EXT-X-VERSION:",
                    "#EXT-X-TARGETDURATION:",
                    "#EXT-X-ALLOW-CACHE:",
                    "#EXT-X-INDEPENDENT-SEGMENTS",
                )
            )
            or line == "#EXTM3U"
        ):
            globals_.append(line)
        elif line.startswith(("#EXTINF:", "#EXT-X-PROGRAM-DATE-TIME:")):
            pending.append(line)
        elif line.startswith("#"):
            simple = False
            line = re.sub(r'URI="([^"]+)"', lambda m: 'URI="' + local(m[1]) + '"', line)
        else:
            line = local(line)
            refs.append(line)
            blocks.append(tuple(pending + [line]))
            if not any(t.startswith("#EXTINF:") for t in pending):
                raise MediaError("媒体清单缺少分片时长")
            pending.clear()
        rendered.append(line)
    if not refs:
        raise MediaError("清单中没有可播分片")
    if live_record and simple and blocks:
        first_date = next(
            (
                v.partition(":")[2]
                for v in blocks[0]
                if v.startswith("#EXT-X-PROGRAM-DATE-TIME:")
            ),
            None,
        )
        if first_date:
            first = int(
                dt.datetime.fromisoformat(first_date.replace("Z", "+00:00")).timestamp()
            )
    return Manifest(
        "\n".join(rendered) + "\n",
        refs,
        first or 0,
        blocks,
        globals_,
        simple and first is not None,
    )


class LiveWindow:
    def __init__(self):
        self.blocks = {}
        self.end = None
        self.source = None
        self.offset = 0
        self.published = -1
        self.boundary = None
        self.discontinuities = 0

        self.last_discontinuity = 0
        self.passthrough = False
        self.floor = 0

    def update_tagged(self, listing, base, reset):
        lines = listing.text.splitlines()
        prefix = "#EXT-X-DISCONTINUITY-SEQUENCE:"
        native = next((int(v[len(prefix) :]) for v in lines if v.startswith(prefix)), 0)
        if reset:
            self.discontinuities = (
                self.last_discontinuity - native if self.published >= 0 else 0
            )
            self.boundary = base if self.published >= 0 else None
        if self.boundary is not None and base > self.boundary:
            self.discontinuities += 1
            self.boundary = None
        sequence = base + self.offset
        disc = native + self.discontinuities
        result = ["#EXTM3U", f"#EXT-X-MEDIA-SEQUENCE:{sequence}"]
        if disc:
            result.append(f"{prefix}{disc}")
        if self.boundary == base:
            result.append("#EXT-X-DISCONTINUITY")
        implicit_key = None
        original_seq = base
        for line in lines[1:]:
            if line.startswith(("#EXT-X-MEDIA-SEQUENCE:", prefix)):
                continue
            if line.startswith("#EXT-X-KEY:"):
                implicit_key = (
                    line
                    if self.offset and "METHOD=AES-128" in line and "IV=" not in line
                    else None
                )
                if implicit_key:
                    continue
            if not line.startswith("#"):
                if implicit_key:
                    result.append(f"{implicit_key},IV=0x{original_seq:032x}")
                original_seq += 1
            result.append(line)
        self.last_discontinuity = disc + result.count("#EXT-X-DISCONTINUITY")
        self.published = original_seq - 1 + self.offset
        return "\n".join(result) + "\n"

    def update(self, source, listing):
        base = listing.first
        if self.source == source == "JCE" and self.blocks:
            dated = {
                tag: seq
                for seq, block in self.blocks.items()
                for tag in block
                if tag.startswith("#EXT-X-PROGRAM-DATE-TIME:")
            }
            anchors = [
                dated[tag] - i
                for i, block in enumerate(listing.blocks)
                for tag in block
                if tag in dated
            ]
            if anchors and min(anchors) == max(anchors):
                base = anchors[0]
        end = base + len(listing.blocks) - 1
        tagged = not listing.simple
        reset = (
            source != self.source
            or self.end is None
            or end < self.end
            or base > self.end + 1
            or tagged != self.passthrough
        )
        if reset:
            self.blocks.clear()
            self.floor = base
            self.offset = self.published + 1 - base if self.published >= 0 else 0
        self.source, self.end, self.passthrough = source, end, tagged
        if tagged:
            return self.update_tagged(listing, base, reset)
        self.blocks.update(enumerate(listing.blocks, base))
        self.blocks = {
            k: v for k, v in self.blocks.items() if k > end - 36 and k >= self.floor
        }
        last = end - int(len(self.blocks) > 3)
        start = last
        while start - 1 in self.blocks and last - start < 11:
            start -= 1
        lines = list(listing.globals)
        lines.append(f"#EXT-X-MEDIA-SEQUENCE:{start + self.offset}")
        if reset and self.published >= 0:
            self.discontinuities = self.last_discontinuity
            self.boundary = base
        if self.boundary is not None and start > self.boundary:
            self.discontinuities += 1
            self.boundary = None
        if self.discontinuities:
            lines.append(f"#EXT-X-DISCONTINUITY-SEQUENCE:{self.discontinuities}")
        for seq in range(start, last + 1):
            if seq == self.boundary:
                lines.append("#EXT-X-DISCONTINUITY")
            lines.extend(self.blocks[seq])
        self.last_discontinuity = self.discontinuities + lines.count(
            "#EXT-X-DISCONTINUITY"
        )
        self.published = last + self.offset
        return "\n".join(lines) + "\n"


def probe_listing(store, listing):
    data = store.probe(listing.refs[-1])
    if data.lstrip().startswith((b"<", b"#EXTM3U")) or len(data) < 188:
        raise MediaError("首片未返回媒体数据")


class ChannelState:
    def __init__(self):
        self.lock = threading.Lock()
        self.window = LiveWindow()
        self.source = ""
        self.address = None
        self.address_until = self.next = self.progress = 0
        self.tail = self.text = None
        self.last_request = None
        self.watch_since = 0
        self.preparing = False
        self.prepared = None
        self.upgrade_error = ""
        self.cooldown = {}
        self.error = ""


class Gateway:
    def __init__(self, mb=96):
        self.store = MediaStore(mb << 20)
        self.states = {cid: ChannelState() for cid in ROWS}
        self.upgrade_slot = threading.BoundedSemaphore(1)
        self.jce_lock = threading.Lock()
        self.jce_next = 0

    def jce(self, row, start, end):
        with self.jce_lock:
            remaining = self.jce_next - time.monotonic()
            if remaining > 1:
                raise MediaError("JCE 冷却中", 503, math.ceil(remaining))
            if remaining > 0:
                time.sleep(remaining)
            self.jce_next = time.monotonic() + 1
            try:
                url = jce_timeshift_url(row[4], row[3], start, end, row[5])
            except urllib.error.HTTPError as exc:
                with exc:
                    delay = delay_from(exc.headers)
                    if exc.code in (429, 503):
                        delay = max(60, delay)
                        self.jce_next = time.monotonic() + delay
                    raise MediaError(f"JCE HTTP {exc.code}", exc.code, delay) from None
            except RuntimeError as exc:
                if any(
                    text in str(exc).lower()
                    for text in ("频繁", "too many", "rate limit")
                ):
                    self.jce_next = time.monotonic() + 60
                    raise MediaError("JCE 限流", 503, 60) from None
                raise MediaError("JCE 播放地址不可用") from None
        return url, {"User-Agent": "Mozilla/5.0"}

    def source(self, name, row, *, upgrade=False):
        if name == "BK":
            urls, headers = bk_playurls(row[3], row[4], row[5])
            if not urls:
                raise MediaError("BK 缺少播放地址")
            return urls, headers, 180
        if name == "Web":
            return [WEB + "/live/" + row[0] + ".m3u8"], {}, 30
        if name == "Device":
            entry = device_resolver.ensure_channel(row[0])
            if (
                upgrade
                and advertised_rate(entry.rate) < 10
                and not re.search(r"[48]K", entry.rate_name or "", re.I)
            ):
                raise MediaError("设备线路没有返回高码率档位")
            return [entry.final_url], cctv_playback_headers_for_entry(entry), 30
        now = int(time.time())
        url, headers = self.jce(row, now - 90, now + 90)
        return [url], headers, 15

    def prepare_upgrade(self, row, ch, watch):
        try:
            urls, headers, ttl = self.source("Device", row, upgrade=True)
            with ch.lock:
                if ch.watch_since != watch or time.monotonic() - ch.last_request > 24:
                    return
            listing = manifest(row[0], urls[0], headers, self.store, prefer_high=True)
            if listing.simple and len(listing.refs) > 3:
                listing = dataclasses.replace(
                    listing,
                    first=listing.first + len(listing.refs) - 3,
                    refs=listing.refs[-3:],
                    blocks=listing.blocks[-3:],
                )
            self.store.prime(listing.refs[-1])
            with ch.lock:
                if ch.watch_since == watch and ch.source != "Device":
                    ch.cooldown.pop("Device", None)
                    ch.prepared = (time.monotonic(), urls, headers, ttl, listing)
                    ch.upgrade_error = ""
        except Exception as exc:
            with ch.lock:
                ch.upgrade_error = (
                    f"Device {type(exc).__name__} ({getattr(exc, 'code', 502)})"
                )
                ch.cooldown["Device"] = time.monotonic() + max(
                    60, getattr(exc, "delay", 0)
                )
        finally:
            with ch.lock:
                ch.preparing = False
            self.upgrade_slot.release()

    def promotion(self, row, ch, now):
        if ch.last_request is None or now - ch.last_request > 24:
            ch.watch_since = now
            ch.prepared = None
        ch.last_request = now
        if not (
            device_resolver
            and row[0] in DEVICE_IDS
            and ch.text
            and ch.source != "Device"
        ):
            return None
        if ch.prepared:
            ready, ch.prepared = ch.prepared, None
            if now - ready[0] < 15:
                return ready
        if (
            now - ch.watch_since >= 10
            and not ch.preparing
            and now >= ch.cooldown.get("Device", 0)
            and self.upgrade_slot.acquire(blocking=False)
        ):
            ch.preparing = True
            threading.Thread(
                target=self.prepare_upgrade, args=(row, ch, ch.watch_since), daemon=True
            ).start()
        return None

    def live(self, row):
        ch = self.states[row[0]]
        with ch.lock:
            now = time.monotonic()
            warm = bool(ch.text and now - ch.progress < 24)
            upgrade = self.promotion(row, ch, now)
            if (
                not upgrade
                and warm
                and (now < ch.next or now < ch.cooldown.get(ch.source, 0))
            ):
                return ch.text
            routes = ["BK"]
            if device_resolver and row[0] in DEVICE_IDS:
                routes.append("Device")
            if WEB:
                routes.append("Web")
            if row[-1]:
                routes.append("JCE")
            if warm and ch.source in routes:
                routes.remove(ch.source)
                routes.insert(0, ch.source)
            if upgrade:
                routes.remove("Device")
                routes.insert(0, "Device")
            elif ch.preparing and "Device" in routes:
                routes.remove("Device")
            for name in routes:
                if ch.cooldown.get(name, 0) > now:
                    continue
                try:
                    prepared = upgrade if name == "Device" else None
                    if prepared:
                        _, urls, headers, ttl, listing = prepared
                    elif ch.source == name and ch.address and now < ch.address_until:
                        urls, headers = ch.address
                        ttl = None
                    else:
                        urls, headers, ttl = self.source(name, row)
                    for i, url in enumerate(urls):
                        try:
                            if not prepared:
                                listing = manifest(
                                    row[0],
                                    url,
                                    headers,
                                    self.store,
                                    live_record=name == "JCE",
                                    prefer_high=name == "Device",
                                )
                            tail = (
                                name,
                                listing.first + len(listing.blocks) - 1,
                                listing.refs[-1]
                                if "#EXT-X-MEDIA-SEQUENCE:" not in listing.text
                                else "",
                            )
                            if tail == ch.tail and not warm:
                                raise MediaError("清单分片停止推进")
                            if not prepared and (not warm or ch.source != name):
                                probe_listing(self.store, listing)
                            break
                        except (OSError, MediaError, http.client.HTTPException) as exc:
                            if i + 1 == len(urls) or getattr(exc, "code", 0) in (
                                401,
                                403,
                                429,
                                503,
                            ):
                                raise
                    if ch.source != name or not warm:
                        print(f"[{row[0]}] {name} 首片已读取", flush=True)
                    if tail != ch.tail:
                        ch.progress = time.monotonic()
                    ch.tail, ch.source = tail, name
                    ch.text = ch.window.update(name, listing)
                    ch.address = (
                        [url] + [other for other in urls if other != url],
                        headers,
                    )
                    if ttl is not None:
                        ch.address_until = now + ttl
                    ch.next = time.monotonic() + 3
                    ch.error = ""
                    return ch.text
                except (
                    OSError,
                    ValueError,
                    RuntimeError,
                    MediaError,
                    http.client.HTTPException,
                    YsptpError,
                ) as exc:
                    code = getattr(exc, "code", 502)
                    delay = getattr(exc, "delay", 0)
                    if isinstance(exc, urllib.error.HTTPError):
                        delay = delay_from(exc.headers)
                        exc.close()
                    ch.error = f"{name} {type(exc).__name__} ({code})"
                    ch.cooldown[name] = time.monotonic() + max(
                        delay, 60 if code in (401, 403, 429) else 6
                    )
                    if code in (401, 403, 429) and not warm:
                        raise MediaError(ch.error, 503, max(60, delay)) from None
                    if ch.source == name and time.monotonic() - ch.progress < 24:
                        return ch.text
            if warm and time.monotonic() - ch.progress < 24:
                return ch.text
            wait = min(ch.cooldown.get(r, now + 3) for r in routes) - time.monotonic()
            raise MediaError(
                ch.error or "所有直播源暂不可用", 503, max(1, math.ceil(wait))
            )

    def segment_failed(self, key, exc):
        try:
            ref, _ = self.store.lookup(key)
        except MediaError:
            return
        ch = self.states[ref[3]]
        with ch.lock:
            if not ch.text or "/media/" + key + "." not in ch.text:
                return
            code = getattr(exc, "code", 502)
            if code in (410, 416):
                return
            ch.cooldown[ch.source] = time.monotonic() + max(
                getattr(exc, "delay", 0), 60 if code in (401, 403, 429) else 6
            )
            ch.error = f"{ch.source} 分片请求失败 ({code})"
            ch.address = ch.text = None
            ch.progress = ch.next = 0

    def device_live(self, row):
        if not device_resolver or row[0] not in DEVICE_IDS:
            raise MediaError("此频道没有启用设备高码率线路", 422)
        urls, headers, _ = self.source("Device", row, upgrade=True)
        return manifest(row[0], urls[0], headers, self.store, prefer_high=True).text

    def replay(self, row, start, end):
        if not row[-1]:
            raise MediaError("本频道没有回看", 422)
        url, headers = self.jce(row, start, end)
        return manifest(
            row[0], url, headers, self.store, ttl=max(300, end - start + 120)
        ).text


def timestamp(value):
    if re.fullmatch(r"\d{10}|\d{13}", value):
        return int(value[:10])
    if re.fullmatch(r"\d{12}(?:\d{2})?Z?", value):
        raw = value.rstrip("Z")
        dtval = dt.datetime.strptime(
            raw, "%Y%m%d%H%M%S" if len(raw) == 14 else "%Y%m%d%H%M"
        )
        if value.endswith("Z"):
            dtval = dtval.replace(tzinfo=dt.timezone.utc)
    else:
        dtval = dt.datetime.fromisoformat(value.replace("Z", "+00:00"))
    return int(
        (
            dtval
            if dtval.tzinfo
            else dtval.replace(tzinfo=dt.timezone(dt.timedelta(hours=8)))
        ).timestamp()
    )


def replay_window(q):
    start = next((q[k][0] for k in ("start", "utc", "starttime") if k in q), None)
    end = next((q[k][0] for k in ("end", "lutc", "endtime") if k in q), None)
    if "playseek" in q:
        raw = q["playseek"][0]
        match = re.fullmatch(r"(\d{10,14}Z?)-(\d{10,14}Z?)", raw)
        start, end = match.groups() if match else (raw, end)
    if start is None and end is None:
        return None
    try:
        a = timestamp(start or "")
        b = timestamp(end) if end is not None else min(a + 7200, int(time.time()))
        if a >= b or a < 0 or a > time.time() or b > time.time() + 60:
            raise ValueError
        return a, b
    except (ValueError, OverflowError, OSError):
        raise MediaError("回看时间无效", 400) from None


class PlayerHandler(BaseHTTPRequestHandler):
    def log_message(self, *args):
        pass

    def serve(self):
        parts = urlsplit(self.path)
        q = parse_qs(parts.query, keep_blank_values=True)
        path = parts.path
        service = self.server.gateway
        headers = {}
        status = 200
        if path in ("/health", "/diag", "/"):
            payload = {
                "version": VERSION,
                "channels": len(ROWS),
                "device": bool(device_resolver),
                "web_configured": bool(WEB),
            }
            if path == "/diag":
                payload["active"] = {
                    cid: {
                        "source": c.source,
                        "error": c.error,
                        "preparing_high": c.preparing,
                        "upgrade_error": c.upgrade_error,
                    }
                    for cid, c in service.states.items()
                    if c.source or c.error
                }
            body = json.dumps(payload, ensure_ascii=False).encode()
            headers["Content-Type"] = "application/json"
        elif path == "/all.m3u":
            origin = "http://" + self.headers.get(
                "Host", f"127.0.0.1:{self.server.server_port}"
            )
            lines = ['#EXTM3U x-tvg-url="https://epg.zsdc.eu.org/t.xml.gz"']
            for cid, name, group, _, __, quality, tvg, logo, replay in CATALOG:
                if "group" in q and group != q["group"][0]:
                    continue
                if q.get("k4", ["0"])[0] in ("1", "true", "yes") and cid not in (
                    "cctv4k",
                    "cctv8k",
                    "cctv164k",
                ):
                    continue
                catch = (
                    ' catchup="append" catchup-days="7" catchup-source="?playseek=${(b)yyyyMMddHHmmss}-${(e)yyyyMMddHHmmss}"'
                    if replay
                    else ""
                )
                lines.extend(
                    [
                        f'#EXTINF:-1 tvg-id="{tvg}" tvg-logo="{logo}" group-title="{group}"{catch},{name}',
                        f"{origin}/{cid}.m3u8",
                    ]
                )
            body = ("\n".join(lines) + "\n").encode()
            headers["Content-Type"] = MPEGURL
        elif path.endswith(".m3u8"):
            cid = path[1:-5].lower()
            row = ROWS.get(ALIASES.get(cid, cid))
            if not row:
                raise MediaError("未知频道", 404)
            window = replay_window(q)
            if q.get("source") == ["device"]:
                if window:
                    raise MediaError("设备线路仅支持直播", 422)
                text = service.device_live(row)
            else:
                text = service.replay(row, *window) if window else service.live(row)
            body = text.encode()
            headers["Content-Type"] = MPEGURL
        else:
            raise MediaError("未知路径", 404)
        return body, status, headers

    def send_media(self, key):
        with self.server.gateway.store.payload(key, self.headers.get("Range")) as (
            status,
            headers,
            chunks,
        ):
            self.send_response(status)
            for k, v in headers.items():
                self.send_header(k, v)
            self.send_header("Access-Control-Allow-Origin", "*")
            self.end_headers()
            if self.command != "HEAD":
                try:
                    for chunk in chunks:
                        try:
                            self.wfile.write(chunk)
                        except OSError:
                            self.close_connection = True
                            return
                except (OSError, http.client.HTTPException) as exc:
                    self.close_connection = True
                    self.server.gateway.segment_failed(key, exc)

    def do_GET(self):
        try:
            media = re.fullmatch(
                r"/media/([a-f0-9]{64})\.(?:ts|aac|m4s|mp4|vtt|key)",
                urlsplit(self.path).path,
            )
            if media:
                try:
                    self.send_media(media[1])
                except (BrokenPipeError, ConnectionResetError):
                    return
                except (MediaError, OSError, http.client.HTTPException) as exc:
                    if self.command == "GET":
                        self.server.gateway.segment_failed(media[1], exc)
                    raise
                return
            body, status, headers = self.serve()
        except MediaError as exc:
            body, status, headers = (
                str(exc).encode(),
                exc.code,
                {"Content-Type": "text/plain; charset=utf-8"},
            )
            if exc.delay:
                headers["Retry-After"] = str(exc.delay)
        except (
            OSError,
            ValueError,
            RuntimeError,
            http.client.HTTPException,
            YsptpError,
        ) as exc:
            body, status, headers = (
                ("上游请求失败 " + type(exc).__name__).encode(),
                502,
                {},
            )
        try:
            self.send_response(status)
            for k, v in headers.items():
                self.send_header(k, v)
            self.send_header("Content-Length", str(len(body)))
            self.send_header("Access-Control-Allow-Origin", "*")
            self.send_header("Cache-Control", "no-store")
            self.end_headers()
            if self.command != "HEAD":
                self.wfile.write(body)
        except (BrokenPipeError, ConnectionResetError):
            pass

    do_HEAD = do_GET


def run_gateway():
    global WEB, device_resolver
    parser = argparse.ArgumentParser(description="YSP Live 10.0")
    parser.add_argument("port", type=int, nargs="?", default=8767)
    parser.add_argument("--bind", default="0.0.0.0")
    parser.add_argument(
        "--data-dir", default=os.environ.get("YSP_DATA_DIR", str(Path(__file__).parent))
    )
    parser.add_argument("--web-url", default=os.environ.get("YSP_WEB_URL", ""))
    parser.add_argument("--no-4k", action="store_true")
    parser.add_argument("--no-engine", action="store_true")
    parser.add_argument("--cache-mb", type=int, default=96)
    parser.add_argument("--version", action="version", version=VERSION)
    args = parser.parse_args()
    import subprocess, atexit

    WEB = "" if args.no_engine else args.web_url.rstrip("/")
    if not WEB and not args.no_engine:
        root = Path(__file__).resolve().parent
        executable = "iptv-rust.exe" if os.name == "nt" else "iptv-rust"
        binary = root / "ysp-web" / "rust-src" / "target" / "release" / executable
        config = root / "ysp-web" / "channels.yaml"
        if binary.is_file() and config.is_file():
            child = subprocess.Popen(
                [
                    str(binary),
                    "--host",
                    "127.0.0.1",
                    "--port",
                    "8787",
                    "--channels",
                    str(config),
                ],
                stdout=subprocess.DEVNULL,
                stderr=subprocess.DEVNULL,
            )

            def stop_engine():
                if child.poll() is None:
                    child.terminate()
                    try:
                        child.wait(timeout=3)
                    except subprocess.TimeoutExpired:
                        child.kill()
                        child.wait()

            atexit.register(stop_engine)
            WEB = "http://127.0.0.1:8787"
    if not args.no_4k:
        cfg = DeviceConfig(str(Path(args.data_dir) / "ysp10-device.json"))
        Path(args.data_dir).mkdir(parents=True, exist_ok=True)
        device_resolver = Resolver(cfg)
        device_resolver.start_refresh_worker()
        device_resolver.start_heartbeat()
    with ThreadingHTTPServer((args.bind, args.port), PlayerHandler) as srv:
        srv.gateway = Gateway(max(0, args.cache_mb))
        print(
            f"YSP Live {VERSION} | http://127.0.0.1:{srv.server_port}/all.m3u",
            flush=True,
        )
        srv.serve_forever()


if __name__ == "__main__":
    run_gateway()
