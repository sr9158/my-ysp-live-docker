# 📺 央视频全频道直播 v9.6 修订版使用说明

## 📢 首发地址

社区：[Gary's Club](https://t.me/garysclub)  
频道：[Gary's Club Channel](https://t.me/garysclubchannel)  
⚠️ 其他任何分发渠道均非作者本人！

---

## ✨ 核心亮点

1. 保留设备协议与低码率播放路径；可选伴生引擎需运行环境支持
2. 真 4K 超高清，内置全部 64 路独立频道（央视 30 路 + 卫视 34 路）
3. 保留时移回看入口，实际可回看范围与播放结果以上游和播放器支持为准
4. 保留播放列表缓存与换台防抖；9.6 优化低码率限流退避与空闲调度
5. 全链路统一 8767 单端口，多协议内部静默协同、按需调度
6. 开箱即用 Docker 镜像，内置数据持久化与 400 故障自动愈合

---

## 🛠 Python 9.6 修订版（运行版本 9.6.1）

下载路径与文件名仍使用 v9.6，升级后运行版本为 9.6.1。

本次继续调整 Python 9.6 的启播顺序，参考独立 JS 脚本的处理方式：对于符合设备接口条件的频道，冷启动时若没有有效的低码率播放列表缓存，可以直接尝试设备接口，不再等待尚未实际建立的低码率播放阶段。

- **限流退避**：JCE 请求全局串行，间隔至少 2 秒；业务限流或 HTTP 429 触发共享冷却，首次 60 秒，连续限流递增至 900 秒，并遵守更长的 Retry-After。冷却期间不额外请求 JCE，也不切换提供方绕过限流。
- **减少无效刷新**：低码率频道无新播放请求超过 20 秒后停止后台轮询，各频道独立判断；成功拉取的缓存仅在 30 秒新鲜期内复用。
- **调整冷启动顺序**：仅对符合设备接口条件的频道生效；已有有效低码率缓存时仍可先复用缓存。仅支持低码率的频道继续使用低码率路径，不强行切换设备接口。
- **保持接口边界**：不修改高码率与 4K 设备协议；独立 JS 脚本本身保持不变。启播顺序调整不用于绕过上游限流，原有限流退避仍然生效。
- **低码率滚动窗口**：复用有效的 JCE 低码率滚动播放列表，只输出已完成的分片，并保留一个分片的安全余量；不支持或已冻结的数据不会被重新标记为直播，限流冷却仍然生效。
- **验证范围**：当前仅完成模拟数据测试，尚未完成 iOS 端到端实机验证。
- **保留回退**：9.5 文件继续保留；9.6 的脚本、桌面包、Docker 包和说明使用独立文件名。

> 退避是尊重上游限流，不是绕过限制。上游仍在限制时可能暂时无法启播；反复重启、刷新或切台不会保证恢复。不承诺所有频道或所有网络下始终可用。

---

## 💻 电脑版使用方法（PC / Mac / Linux）

1. 下载地址：<https://garysclub.sharewithyou.dpdns.org/ysp-live/ysp-live-v9.6.zip>
2. 安装 Python 3 后运行。Node.js 为可选依赖，仅在下载包包含伴生引擎且运行环境支持时使用；没有 Node.js 不影响 Python 本身启动。
3. 解压进入目录直接运行：
   ```bash
   python3 ysp-live-v9.6.py
   ```
   （可选）后台常驻运行：
   ```bash
   nohup python3 ysp-live-v9.6.py > ysp.log 2>&1 &
   ```
4. 播放器添加订阅地址：`http://localhost:8767/all.m3u`

---

## 🐳 Docker 版使用与升级方法

1. 下载地址：<https://garysclub.sharewithyou.dpdns.org/ysp-live/ysp-live-docker-v9.6.zip>
2. 升级前停用旧容器并保留原有持久化数据，解压进入 9.6 目录。核对 compose 中的数据挂载仍指向原目录后构建启动：
   ```bash
   docker compose up -d --build
   ```
3. 播放器添加订阅地址：
   - 电脑本机播放：`http://localhost:8767/all.m3u`
   - 局域网播放：`http://你的局域网IP:8767/all.m3u`

---

## 📱 APTV / iOS 使用方法

1. 升级时先停用 9.5 服务，避免两份服务争用 8767 端口；保留原服务以便回退。点击 “配置” ➔ “服务” ➔ “添加服务”
2. 服务名称：`央视频直播`
3. 服务类型：`Python`
4. 代码来源选择 “远程链接”，地址填写：`https://garysclub.sharewithyou.dpdns.org/ysp-live/ysp-live-v9.6.py`
5. 点击 “加载代码” ➔ 划到底部点击 “添加服务” ➔ 打开服务开关
6. 前往 APTV “添加订阅”，地址填写：`http://127.0.0.1:8767/all.m3u`

若原服务支持更换代码链接，可将地址改为 9.6 后重新加载。iOS 环境不支持伴生引擎时，不要把“未找到 ysp-engine.js”单独视为 Python 启动失败。

---

## 🚀 翻墙/代理工具分流配置

1. **小火箭（Shadowrocket）分流规则**：  
   打开小火箭，点击底部 「配置」 -> 「模块」。  
   点击右上角 「+」，粘贴模块链接： `https://garysclub.sharewithyou.dpdns.org/ysp-live/ysp.module`
2. **通用规则集（Surge / Loon / Clash 等）**：  
   规则集地址：`https://garysclub.sharewithyou.dpdns.org/ysp-live/ysp.list`

---

## ↩️ 回退与排障

- 先停止 9.6，再启动保留的 9.5；不要同时启动两个占用 8767 的服务。
- 历史桌面包：<https://garysclub.sharewithyou.dpdns.org/ysp-live/ysp-live-v9.5.zip>
- 历史 Docker 包：<https://garysclub.sharewithyou.dpdns.org/ysp-live/ysp-live-docker-v9.5.zip>
- 历史脚本：<https://garysclub.sharewithyou.dpdns.org/ysp-live/ysp-live-v9.5.py>
- 原有运行数据不要清空。遇到问题先保存频道名、时间和错误类型；分享日志前删除设备标识、签名、令牌和完整播放地址。
- 健康检查：`http://localhost:8767/health`；诊断：`http://localhost:8767/diag`。其他设备访问时，将 localhost 换成服务所在设备的局域网 IP。
- 观看流量随实际码率变化，4K 通常显著高于普通清晰度。请确认网络与数据套餐。
- 本地服务请仅在可信网络使用。是否能播放仍受上游授权、网络、频道状态及运行环境影响。

---

## 🙏 特别感谢

1. 感谢 **IPTV 直播源总部** 分享的算法源码
2. 感谢 **Gary's Club** 群里小伙伴 **ll** 提供大量频道的 live_id
3. 感谢 **APTV 群主** 提供的技术帮助

