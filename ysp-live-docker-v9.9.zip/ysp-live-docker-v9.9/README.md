# 📺 央视频全频道直播 v9.9.1 使用说明

## 📢 首发地址

社区：[Gary's Club](https://t.me/garysclub)  
频道：[Gary's Club Channel](https://t.me/garysclubchannel)  
⚠️ 其他任何分发渠道均非作者本人！

---

## ✨ 核心亮点

1. 保留设备协议与低码率播放路径；可选伴生引擎需运行环境支持
2. 真 4K 超高清，内置全部 64 路独立频道（央视 30 路 + 卫视 34 路）
3. 保留时移回看入口，实际可回看范围与播放结果以上游和播放器支持为准
4. 已有可用缓冲时保留低码率换台防抖，按分片进展判断直播缓存是否可用
5. 全链路统一 8767 单端口，多协议内部静默协同、按需调度
6. 开箱即用 Docker 镜像，内置数据持久化与 400 故障自动愈合

---

## 🛠 Python 9.9.1 更新说明

9.9.1 是 9.9 的启播补丁，沿用 9.9 文件名和下载地址。APTV 使用原来的远程脚本地址重新加载并重启服务，确认启动日志或 `/health` 显示 9.9.1。

- **首次启播**时，已启用且就绪的设备线路在没有可用低码率缓冲时立即开始获取清单。有可用缓冲时仍按换台防抖设置播放，纯低码率频道继续使用原有路径。设备线路首次交付清单时写入运行日志。
- **切离频道**后，该频道连续 20 秒没有新的低码率播放请求就停止发起后台轮询。

- **缓存有效期**取决于低码率直播分片最后一次向前推进的时间。30 秒内可复用缓冲。反复收到相同分片或重新生成清单都不会延长有效期。
- **JCE 限流**时，直播刷新和时移请求共享地址解析冷却。HTTP 429 或明确的业务限流触发至少 60 秒退避，连续限流逐次翻倍至 900 秒，并尊重更长的 Retry-After。媒体清单返回 429 时只冷却该频道。
- **播放器响应**会优先使用仍然有效的直播缓冲。JCE 冷却期间，低码率直播没有可用缓冲时返回 HTTP 503 和 Retry-After。时移请求遇到限流也会返回等待时间。
- **备用线路**沿用 9.5 的选择规则。JCE 返回已知失效域名时切到 bkliveinfo。其他非限流故障在缺少有效本地清单时尝试伴生引擎。运行日志和 `/diag` 会显示引擎返回了清单、端口未监听或具体 HTTP 状态。

---

## 💻 电脑版使用方法（PC / Mac / Linux）

1. 下载地址：<https://garysclub.sharewithyou.dpdns.org/ysp-live/ysp-live-v9.9.zip>
2. 安装 Python 3 后运行。Node.js 为可选依赖，仅在下载包包含伴生引擎且运行环境支持时使用；没有 Node.js 不影响 Python 本身启动。
3. 解压进入目录直接运行：
   ```bash
   python3 ysp-live-v9.9.py
   ```
   （可选）后台常驻运行：
   ```bash
   nohup python3 ysp-live-v9.9.py > ysp.log 2>&1 &
   ```
4. 播放器添加订阅地址：`http://localhost:8767/all.m3u`

---

## 🐳 Docker 版使用与升级方法

1. 下载地址：<https://garysclub.sharewithyou.dpdns.org/ysp-live/ysp-live-docker-v9.9.zip>
2. 升级前停用旧容器并保留原有持久化数据，解压进入 9.9 目录。核对 compose 中的数据挂载仍指向原目录后构建启动：
   ```bash
   docker compose up -d --build
   ```
3. 播放器添加订阅地址：
   - 电脑本机播放：`http://localhost:8767/all.m3u`
   - 局域网播放：`http://你的局域网IP:8767/all.m3u`

---

## 📱 APTV / iOS 使用方法

1. 升级时先停用旧服务，避免两份服务争用 8767 端口。点击 “配置” ➔ “服务” ➔ “添加服务”
2. 服务名称：`央视频直播`
3. 服务类型：`Python`
4. 代码来源选择 “远程链接”，地址填写：`https://garysclub.sharewithyou.dpdns.org/ysp-live/ysp-live-v9.9.py`
5. 点击 “加载代码” ➔ 划到底部点击 “添加服务” ➔ 打开服务开关
6. 前往 APTV “添加订阅”，地址填写：`http://127.0.0.1:8767/all.m3u`

若原服务支持更换代码链接，可将地址改为 9.9 后重新加载。iOS 环境不支持伴生引擎时，不要把“未找到 ysp-engine.js”单独视为 Python 启动失败。

---

## nanoTV TF / JavaScript 订阅

1. 打开“设置 → 通用 → 实验”，启用“JS订阅”。
2. 打开“订阅 → 添加 → JavaScript”。
3. 填写脚本地址：`https://garysclub.sharewithyou.dpdns.org/ysp-live/ysp-service_2.0.16.js`
4. 点击「读取脚本」→「批准并安装」，然后启用服务。

这是独立 JS 脚本，内部版本为 `2.0.16`；它不是 Python 9.9 的版本号。本次不修改该 JS 文件。

---

## mytv-android 当前预览版 / 脚本服务

以下入口按当前预览版说明整理，实际名称以所安装版本为准。

1. **准备运行环境**：Python 方式要求 Android 7 及以上，并安装“Python运行环境”组件。可在设置或 Web 面板中搜索组件，或进入“设置 → 投屏与扩展 → 组件下载”安装。JavaScript 方式不需要 Python 组件。
2. 搜索“脚本服务”并选择“添加服务”，或进入“设置 → 投屏与扩展 → 脚本服务 → 添加服务”。
3. 名称填写“央视频直播”，代码来源选择“远程链接”；按所选脚本类型填入地址：
   - Python：`https://garysclub.sharewithyou.dpdns.org/ysp-live/ysp-live-v9.9.py`
   - JavaScript：`https://garysclub.sharewithyou.dpdns.org/ysp-live/ysp-service_2.0.16.js`
4. 勾选“启用” → “确定”。
5. 长按该服务 → “添加为订阅源”。

JS 文件仍为独立版本 2.0.16，本次不修改。上述为配置指引，不代表已完成该预览版端到端实机验证。

---

## 🚀 翻墙/代理工具分流配置

1. **小火箭（Shadowrocket）分流规则**：  
   打开小火箭，点击底部 「配置」 -> 「模块」。  
   点击右上角 「+」，粘贴模块链接： `https://garysclub.sharewithyou.dpdns.org/ysp-live/ysp.module`
2. **通用规则集（Surge / Loon / Clash 等）**：  
   规则集地址：`https://garysclub.sharewithyou.dpdns.org/ysp-live/ysp.list`

---

## 排障与使用边界

- 原有运行数据不要清空。遇到问题先保存频道名、时间和错误类型；分享日志前删除设备标识、签名、令牌和完整播放地址。
- 健康检查：`http://localhost:8767/health`；诊断：`http://localhost:8767/diag`。其他设备访问时，将 localhost 换成服务所在设备的局域网 IP。
- 观看流量随实际码率变化，4K 通常显著高于普通清晰度。请确认网络与数据套餐。
- 本地服务请仅在可信网络使用。是否能播放仍受上游授权、网络、频道状态及运行环境影响。

---

## 🙏 特别感谢

1. 感谢 **IPTV 直播源总部** 分享的算法源码
2. 感谢 **Gary's Club** 群里小伙伴 **ll** 提供大量频道的 live_id
3. 感谢 **APTV 群主** 提供的技术帮助

